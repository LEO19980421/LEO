/***********************************************************************
�ļ����ƣmmain.h

***********************************************************************/
#ifndef __MAIN_H
#define __MAIN_H
#include "stm32f4xx.h"
#include "stm32f4xx_can.h"
#include "stm32f4xx_flash.h"
#include "stm32f4xx_pwr.h"
#include "stm32f4xx_iwdg.h"
#include "mainconf.h"
#include "TIMER.h"
#include "hardware.h"
#include "CAN.h"
#include "delay.h"
#include "RCCconfig.h"
#include "pwm.h"
#include "data_handle.h"
#include "arm_math.h"
#include "config.h"
#include "PID.h"   
#include "DAC.h"
#include "Parmater_config.h"
#include "Signalprocess.h"
#include "flash.h"
#include "ADC_8.H"
#include <stdio.h>
#include <stdlib.h>
#include <stm32f4xx_adc.h>
#include <math.h>
#include <task.h>


#define SYSTEMTICK_PERIOD_MS  10
#define IAPKEY		0x00000000   //���APPһ��
void Display(void);//OLED ��ʾ
void RestartCPU(void);//������Ƭ��
void Initilize_CAT24C32(void);//��ȡ��һ�ι���״̬
void Power_staus_check(void);//��ȡ��Դ״̬
void PID_change(void);
void Factory_value_status(void); 
//void KeyProcess(void);//��������

//void Delay_us(uint32_t x);

#endif
