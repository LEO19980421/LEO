#include "CAN.h"
#include "stm32f4xx.h"
#include "hardware.h"
#include "config.h"
#include "Parmater_config.h"
#include "flash.h"
#include "data_handle.h"
#include "delay.h"
#include "pwm.h"
#include "hardware.h"
#include "ADC_8.h"


CanRxMsg RxMessage;
extern float duty,Q_duty,P_duty;
extern uint8_t AI1type,AI2type;//ģ�����������ͣ�����ģ�����������Ͷ���
extern uint8_t AI1type,AI2type,AI3type,AI4type;//ģ�����������ͣ�����ģ�����������Ͷ���
u8 can_test[8];
extern u8 Power_enforce;
extern  float ADCvalue_Percent[8];
int Runmode,DAC_ONOFF;
int    minzerovalue=0.0,maxzerovalue=0,Offset_zero=0,
	     Q_ZERO=0,P_ZERO=0,Q_Offset=0; //����������������
int     Input_type=0,   Input_P_type=0,Input_Q_type=0,   //������������
        Output_type_P=0,Output_type_Q=0;  //��оλ��ģ���������ѹ��ģ�������
int    Q_Limit_Min=0,Q_Limit_Max=0,P_Limit_Max=0,P_Limit_Min=0;
int     sign_Positive=1;  //ѹ�������������趨
int     P_Factor_A1=0,P_Factor_B1=0,Q_Factor_A1=0,Q_Factor_B1=0,P_Offset1=0,Q_Offset1=0,
        P_Factor_A2=0,P_Factor_B2=0,Q_Factor_A2=0,Q_Factor_B2=0,P_Offset2=0,Q_Offset2=0,
        P_Factor_A3=0,P_Factor_B3=0,Q_Factor_A3=0,Q_Factor_B3=0,
        Q_Factor_A4=0,Q_Factor_B4=0;
float I_Target=0,P_Target=0,Q_Target=0;//������ѹ����������������
float  TS_position_max=0.0, TS_position_min=0.0,Current_limit_min=0.0,Current_limit_max=0.0;  //�޷�����

float  P_close_loop_P=0.0,P_close_loop_I=0.0,P_close_loop_D=0.0,
	     Q_close_loop_P=0.0,Q_close_loop_I=0.0,Q_close_loop_D=0.0,
       I_close_loop_P=0.0,I_close_loop_I=0.0,I_close_loop_D=0.0; ////ѹ��������������������
float  I_default=0.0,Spool_default=0.0,Spool_zero_default=0.0;
u8     Flag_PIDchange_Flow=0,Flag_PIDchange_Pre=0,Flag_PIDchange_Current=0,CPU_restart=0;
u8     PWM_FLAG=0;
u32   test_can=0;
float float_test=0.0;
u32 duty_ask=0;
const unsigned int CAN_baud_table[CAN_BAUD_NUM][5] = 
{
//�����ʣ� CAN_SJW��   CAN_BS1��    CAN_BS2��CAN_Prescaler 
	{5,   CAN_SJW_1tq,CAN_BS1_16tq,CAN_BS2_2tq,884},		//5k		
	{10,  CAN_SJW_1tq,CAN_BS1_13tq,CAN_BS2_2tq, 525},		//10k		
	{15,  CAN_SJW_1tq,CAN_BS1_16tq,CAN_BS2_3tq,280},		//15K
	{20,  CAN_SJW_1tq,CAN_BS1_16tq, CAN_BS2_5tq,191},		//20k
	{25,  CAN_SJW_1tq,CAN_BS1_16tq,CAN_BS2_4tq,160},			//25k
	{40,  CAN_SJW_1tq,CAN_BS1_16tq, CAN_BS2_3tq,105},		//40k
	{50,  CAN_SJW_1tq,CAN_BS1_16tq,CAN_BS2_3tq,84},			//50k
	{62,  CAN_SJW_1tq,CAN_BS1_16tq,CAN_BS2_7tq,56},			//62.5k
	{80,  CAN_SJW_1tq,CAN_BS1_13tq, CAN_BS2_7tq,50},			//80k
	{100, CAN_SJW_1tq,CAN_BS1_14tq, CAN_BS2_6tq,40},			//100K
	{125, CAN_SJW_1tq,CAN_BS1_13tq, CAN_BS2_7tq,32},		//125K
	{200, CAN_SJW_1tq,CAN_BS1_13tq, CAN_BS2_7tq,20},			//200K
	{250, CAN_SJW_1tq,CAN_BS1_6tq,CAN_BS2_5tq,28},		    //250k
	{400, CAN_SJW_1tq,CAN_BS1_3tq, CAN_BS2_3tq,30},			//400K
	{500, CAN_SJW_1tq,CAN_BS1_7tq, CAN_BS2_6tq,6},			//500K
	{600, CAN_SJW_1tq,CAN_BS1_6tq, CAN_BS2_7tq,10},			//600
	{800, CAN_SJW_1tq,CAN_BS1_3tq, CAN_BS2_3tq,25},			//800K
	{1000,CAN_SJW_1tq,CAN_BS1_5tq, CAN_BS2_8tq,6},			//1000K
};
extern int arr_flag,psc_flag;

/***********************************************************************
�ļ����ƣ�CAN_Baud_Process
��    �ܣ����㲨���ʣ�����
��дʱ�䣺2013.4.25
�� д �ˣ�
ע    �⣺
CAN_SJW : CAN_SJW_1tq - CAN_SJW_4tq	  ���ܱ��κ�һ��λ����γ�
CAN_BS1 : CAN_BS1_1tq - CAN_BS1_16tq
CAN_BS2 : CAN_BS2_1tq - CAN_BS2_8tq
CAN_Prescaler : 1 - 1024
	����˵����
CAN_SJW + CAN_BS1 / (CAN_SJW + CAN_BS1 + CAN_BS2)
	0.75     baud > 800k
	0.80     baud > 500k
	0.875    baud <= 500k
	baud = 36 / (CAN_SJW + CAN_BS1 + CAN_BS2) / CAN_Prescaler
***********************************************************************/
void CAN_Baud_Process(unsigned int Baud,CAN_InitTypeDef *CAN_InitStructure)
{
	unsigned int i = 0;
	for(i = 0;i < CAN_BAUD_NUM;i ++)
	{
		if(Baud == CAN_baud_table[i][0])
		{
			CAN_InitStructure->CAN_SJW = CAN_baud_table[i][1];
			CAN_InitStructure->CAN_BS1 = CAN_baud_table[i][2];
			CAN_InitStructure->CAN_BS2 = CAN_baud_table[i][3];
			CAN_InitStructure->CAN_Prescaler = CAN_baud_table[i][4];
			break;	
		}
	}	
}

void CAN1_Configuration(unsigned int Baud)
{

  	GPIO_InitTypeDef GPIO_InitStructure; 
	  CAN_InitTypeDef        CAN_InitStructure;
  	CAN_FilterInitTypeDef  CAN_FilterInitStructure;
//   	NVIC_InitTypeDef  NVIC_InitStructure;
    //ʹ�����ʱ��
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);//ʹ��PORTAʱ��	                   											 

  	RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);//ʹ��CAN1ʱ��	
	
    //��ʼ��GPIO
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11| GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;//���ù���
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
    GPIO_Init(GPIOA, &GPIO_InitStructure);//��ʼ��PA11,PA12
	
	  //���Ÿ���ӳ������
	  GPIO_PinAFConfig(GPIOA,GPIO_PinSource11,GPIO_AF_CAN1); //GPIOA11����ΪCAN1
	  GPIO_PinAFConfig(GPIOA,GPIO_PinSource12,GPIO_AF_CAN1); //GPIOA12����ΪCAN1
	  
  	//CAN��Ԫ����
   	CAN_InitStructure.CAN_TTCM=DISABLE;	//��ʱ�䴥��ͨ��ģʽ   
  	CAN_InitStructure.CAN_ABOM=DISABLE;	//�����Զ����߹���	  
  	CAN_InitStructure.CAN_AWUM=DISABLE;//˯��ģʽͨ����������(���CAN->MCR��SLEEPλ)
  	CAN_InitStructure.CAN_NART=ENABLE;	//��ֹ�����Զ����� 
  	CAN_InitStructure.CAN_RFLM=DISABLE;	//���Ĳ�����,�µĸ��Ǿɵ�  
  	CAN_InitStructure.CAN_TXFP=DISABLE;	//���ȼ��ɱ��ı�ʶ������ 
  	CAN_InitStructure.CAN_Mode= CAN_Mode_Normal;	 //ģʽ���� 
//  	CAN_InitStructure.CAN_SJW=tsjw;	//����ͬ����Ծ����(Tsjw)Ϊtsjw+1��ʱ�䵥λ CAN_SJW_1tq~CAN_SJW_4tq
//  	CAN_InitStructure.CAN_BS1=tbs1; //Tbs1��ΧCAN_BS1_1tq ~CAN_BS1_16tq
//  	CAN_InitStructure.CAN_BS2=tbs2;//Tbs2��ΧCAN_BS2_1tq ~	CAN_BS2_8tq
//  	CAN_InitStructure.CAN_Prescaler=brp;  //��Ƶϵ��(Fdiv)Ϊbrp+1	
	  CAN_Baud_Process(Baud,&CAN_InitStructure);//������
  	CAN_Init(CAN1, &CAN_InitStructure);   // ��ʼ��CAN1 
    
		//���ù�����
 	  CAN_FilterInitStructure.CAN_FilterNumber=0;	  //������0
  	CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask; 
  	CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit; //32λ 
  	CAN_FilterInitStructure.CAN_FilterIdHigh=0x0000;////32λID
  	CAN_FilterInitStructure.CAN_FilterIdLow=0x0000;
  	CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0x0000;//32λMASK
  	CAN_FilterInitStructure.CAN_FilterMaskIdLow=0x0000;
   	CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_Filter_FIFO0;//������0������FIFO0
  	CAN_FilterInitStructure.CAN_FilterActivation=ENABLE; //���������0
  	CAN_FilterInit(&CAN_FilterInitStructure);//�˲�����ʼ��
	CAN_ITConfig(CAN1,CAN_IT_FMP0,ENABLE);//FIFO0��Ϣ�Һ��ж�����.		
}   

void CAN2_Configuration(unsigned int Baud)
{

  	GPIO_InitTypeDef GPIO_InitStructure; 
	  CAN_InitTypeDef        CAN_InitStructure;
  	CAN_FilterInitTypeDef  CAN_FilterInitStructure;
//   	NVIC_InitTypeDef  NVIC_InitStructure;
    //ʹ�����ʱ��
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);//ʹ��PORTBʱ��	                   											 

  	RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN2, ENABLE);//ʹ��CAN2ʱ��	
	
    //��ʼ��GPIO
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12| GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;//���ù���
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
    GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��PB12,PB13
	
	  //���Ÿ���ӳ������
	  GPIO_PinAFConfig(GPIOB,GPIO_PinSource12,GPIO_AF_CAN2); //GPIOB12����ΪCAN2
	  GPIO_PinAFConfig(GPIOB,GPIO_PinSource13,GPIO_AF_CAN2); //GPIOB13����ΪCAN2
	  
  	//CAN��Ԫ����
   	CAN_InitStructure.CAN_TTCM=DISABLE;	//��ʱ�䴥��ͨ��ģʽ   
  	CAN_InitStructure.CAN_ABOM=DISABLE;	//�����Զ����߹���	  
  	CAN_InitStructure.CAN_AWUM=DISABLE;//˯��ģʽͨ����������(���CAN->MCR��SLEEPλ)
  	CAN_InitStructure.CAN_NART=ENABLE;	//��ֹ�����Զ����� 
  	CAN_InitStructure.CAN_RFLM=DISABLE;	//���Ĳ�����,�µĸ��Ǿɵ�  
  	CAN_InitStructure.CAN_TXFP=DISABLE;	//���ȼ��ɱ��ı�ʶ������ 
  	CAN_InitStructure.CAN_Mode= CAN_Mode_Normal;	 //ģʽ���� 
//  	CAN_InitStructure.CAN_SJW=tsjw;	//����ͬ����Ծ����(Tsjw)Ϊtsjw+1��ʱ�䵥λ CAN_SJW_1tq~CAN_SJW_4tq
//  	CAN_InitStructure.CAN_BS1=tbs1; //Tbs1��ΧCAN_BS1_1tq ~CAN_BS1_16tq
//  	CAN_InitStructure.CAN_BS2=tbs2;//Tbs2��ΧCAN_BS2_1tq ~	CAN_BS2_8tq
//  	CAN_InitStructure.CAN_Prescaler=brp;  //��Ƶϵ��(Fdiv)Ϊbrp+1	
	  CAN_Baud_Process(Baud,&CAN_InitStructure);//������
  	CAN_Init(CAN2, &CAN_InitStructure);   // ��ʼ��CAN2 
    
		//���ù�����
 	  CAN_FilterInitStructure.CAN_FilterNumber=0;	  //������0
  	CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask; 
  	CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit; //32λ 
  	CAN_FilterInitStructure.CAN_FilterIdHigh=0x0000;////32λID
  	CAN_FilterInitStructure.CAN_FilterIdLow=0x0000;
  	CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0x0000;//32λMASK
  	CAN_FilterInitStructure.CAN_FilterMaskIdLow=0x0000;
   	CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_Filter_FIFO0;//������0������FIFO0
  	CAN_FilterInitStructure.CAN_FilterActivation=ENABLE; //���������0
  	CAN_FilterInit(&CAN_FilterInitStructure);//�˲�����ʼ��
	  
}   
  
//�жϷ�����	    
void CAN1_RX0_IRQHandler(void)//�����������յ������� 
{
  	int16_t value = 0,Q_value=0,P_value=0;
	u16 ARR_pwm=0,PSC_pwm=0;
    uint32_t ID = 0; int kkkcan=0;
	  uint32_t Value1 = 0,Value2 = 0;
	int buf[8]={0};
int CAN_ASK_buf[8]={0};
//	  u8 buf[8]={0};
		RxMessage.StdId=0x00;
		RxMessage.ExtId=0x00;
		RxMessage.IDE=0;
		RxMessage.DLC=0;
		RxMessage.FMI=0;
		RxMessage.Data[0]=0x00;     
	  CAN_Receive(CAN1, 0, &RxMessage);
		ID=RxMessage.ExtId;
		  if(ID==CANID_SET)
		{
			  if(RxMessage.Data[0]==1)//���ܺţ�1
				{
					if(RxMessage.Data[1]==1)//��������     ��1
					{    							
						Runmode=RxMessage.Data[1];
						duty=Int_To_Float((RxMessage.Data[5]<<24)+(RxMessage.Data[4]<<16)+(RxMessage.Data[3]<<8)+RxMessage.Data[2]);
						
						if(duty>120)
						duty=duty-65536;
						buf[0]=RxMessage.Data[2];
						buf[1]=RxMessage.Data[3];
						buf[2]=RxMessage.Data[4];
						buf[3]=RxMessage.Data[5];
						buf[4]=RxMessage.Data[0];
						WriteOneByte(MCurrent_OpenPwm11,buf[0]);
						WriteOneByte(MCurrent_OpenPwm12,buf[1]);
 						WriteOneByte(MCurrent_OpenPwm13,buf[2]);
						WriteOneByte(MCurrent_OpenPwm14,buf[3]);
						WriteOneByte(M_runmode, buf[4]); 
						
//					P_close_loop_P=((RxMessage.Data[4]<<24)+(RxMessage.Data[3]<<16)+(RxMessage.Data[2]<<8)+RxMessage.Data[1]);
//					P_close_loop_P=Int_To_Float(P_close_loop_P);
//					buf[0]=RxMessage.Data[1];
//					buf[1]=RxMessage.Data[2];
//					buf[2]=RxMessage.Data[3];
//				   	buf[3]=RxMessage.Data[4];
//				  	WriteOneByte(MP_close_loop_P11, buf[0]); 
//					WriteOneByte(MP_close_loop_P12, buf[1]);   
//					WriteOneByte(MP_close_loop_P13, buf[2]);  
//				    WriteOneByte(MP_close_loop_P14, buf[3]);	
//					Flag_PIDchange_Pre=1;
					}
					else if(RxMessage.Data[1]==2)//�����ջ�  
				{
					Runmode=RxMessage.Data[1];
					value=Int_To_Float((RxMessage.Data[5]<<24)+(RxMessage.Data[4]<<16)+(RxMessage.Data[3]<<8)+RxMessage.Data[2]);
					buf[0]=RxMessage.Data[2];
					buf[1]=RxMessage.Data[3];
					buf[2]=RxMessage.Data[4];
					buf[3]=RxMessage.Data[5];
					buf[4]=Runmode;
				
					WriteOneByte(MCurrent_CloseValue_Set11,buf[0]);
					WriteOneByte(MCurrent_CloseValue_Set12,buf[1]);
					WriteOneByte(MCurrent_CloseValue_Set13,buf[2]);
					WriteOneByte(MCurrent_CloseValue_Set14,buf[3]);
		    		I_Target=value/1.0;
					WriteOneByte(M_runmode, buf[4]);
				}

						else if(RxMessage.Data[1]==4)//�����ջ�         ���ָ���
            {
                Runmode=RxMessage.Data[1];
               	Q_value=(RxMessage.Data[4]<<8)+RxMessage.Data[5];
				Input_type=0;
                buf[0]=RxMessage.Data[4];
                buf[1]=RxMessage.Data[5];
							  buf[2]=RxMessage.Data[1];	
							  buf[3]=0;
                WriteOneByte(MSpool_CloseValue_Set11,buf[0]);
							  WriteOneByte(MSpool_CloseValue_Set12,buf[1]);
					  		WriteOneByte(M_runmode, buf[2]);
							  WriteOneByte(MTarget_type12, buf[3]);
								WriteOneByte(M_Input_type, buf[3]);
                Q_Target=Q_value;						    
            }
			      else if(RxMessage.Data[1]==6)//ѹ���ջ�   ���ָ���
            {
                  Runmode=RxMessage.Data[1];
                  P_value=(RxMessage.Data[6]<<8)+RxMessage.Data[7];
                  P_Target=P_value;
						    	
 							    Input_type=0;
                  buf[2]=RxMessage.Data[1];
                  buf[0]=RxMessage.Data[6];
                  buf[1]=RxMessage.Data[7];
							    buf[3]=0;
						      WriteOneByte(MP_CloseValue_Set11, buf[0]);
					        WriteOneByte(MP_CloseValue_Set12, buf[1]);
						      WriteOneByte(M_runmode, buf[2]);
									WriteOneByte(MTarget_type11, buf[3]);
									WriteOneByte(M_Input_type, buf[3]);
            }
						 

				}
        else if(RxMessage.Data[0]==2)//���ܺţ�2  ����������������
        {
            Input_type=RxMessage.Data[0];
            Input_P_type=RxMessage.Data[1];
            Input_Q_type=RxMessage.Data[2];
            buf[0]=RxMessage.Data[0];
            buf[1]=RxMessage.Data[1];
					  buf[2]=RxMessage.Data[2];
					  WriteOneByte(M_Input_type, buf[0]);
					  WriteOneByte(MTarget_type11, buf[1]);
					  WriteOneByte(MTarget_type12, buf[2]);		
			
         }
        else if(RxMessage.Data[0]==3)//���ܺţ�3  ��оλ��ģ�����������
        {
            Output_type_Q=RxMessage.Data[0];
		    DAC_ONOFF=1;
            Q_Factor_A1=(RxMessage.Data[1]<<8)+RxMessage.Data[2];
            Q_Factor_B1=(RxMessage.Data[3]<<8)+RxMessage.Data[4];
            Q_Offset1=(RxMessage.Data[5]<<8)+RxMessage.Data[6];
            buf[1]=RxMessage.Data[1];
			   		buf[2]=RxMessage.Data[2];
            buf[3]=RxMessage.Data[3];
					  buf[4]=RxMessage.Data[4];
            buf[5]=RxMessage.Data[5];
					  buf[6]=RxMessage.Data[6];
	          WriteOneByte(MQ_Factor_A11, buf[1]);
					  WriteOneByte(MQ_Factor_A12, buf[2]);		
					  WriteOneByte(MQ_Factor_B11, buf[3]);
					  WriteOneByte(MQ_Factor_B12, buf[4]);	
					  WriteOneByte(MQ_Offset11, buf[5]); 
					  WriteOneByte(MQ_Offset12, buf[6]);			
        }
       else if(RxMessage.Data[0]==4)//���ܺţ�4  ѹ�����ģ�����������
        {   
					  Output_type_P=RxMessage.Data[0];
						if(DAC_ONOFF==1) DAC_ONOFF=2;
            P_Factor_A1=(RxMessage.Data[1]<<8)+RxMessage.Data[2];
            P_Factor_B1=(RxMessage.Data[3]<<8)+RxMessage.Data[4];
            P_Offset1=(RxMessage.Data[5]<<8)+RxMessage.Data[6];
					  buf[1]=RxMessage.Data[1];
			   		buf[2]=RxMessage.Data[2];
            buf[3]=RxMessage.Data[3];
					  buf[4]=RxMessage.Data[4];
            buf[5]=RxMessage.Data[5];
					  buf[6]=RxMessage.Data[6];
					  WriteOneByte(MP_Factor_A11, buf[1]); 
					  WriteOneByte(MP_Factor_A12, buf[2]);	 
					  WriteOneByte(MP_Factor_B11, buf[3]); 
					  WriteOneByte(MP_Factor_B12, buf[4]);	 
						WriteOneByte(MP_Offset11, buf[5]); 
					  WriteOneByte(MP_Offset12, buf[6]);
        }
       else if(RxMessage.Data[0]==5)//���ܺţ�5  ���������޷�ֵ����	
        {
						 Q_Limit_Min=((RxMessage.Data[1]<<8)+RxMessage.Data[2]);
						 Q_Limit_Max=((RxMessage.Data[3]<<8)+RxMessage.Data[4]);		
             buf[1]=RxMessage.Data[1];
             buf[2]=RxMessage.Data[2];
					    buf[3]=RxMessage.Data[3];
             buf[4]=RxMessage.Data[4];
						 WriteOneByte(MQ_Limit_Min11, buf[1]); 
					   WriteOneByte(MQ_Limit_Min12, buf[2]);	 
						 WriteOneByte(MQ_Limit_Max11, buf[3]); 
					   WriteOneByte(MQ_Limit_Max12, buf[4]);	 	
					
			  }
       else if(RxMessage.Data[0]==6)//���ܺţ�6  �����������ű�������
        {     
            Q_Factor_A2=(RxMessage.Data[1]<<8)+RxMessage.Data[2];
            Q_Factor_B2=(RxMessage.Data[3]<<8)+RxMessage.Data[4];
            Q_Offset2=(RxMessage.Data[5]<<8)+RxMessage.Data[6];			
            buf[1]=RxMessage.Data[1];
            buf[2]=RxMessage.Data[2];
					  buf[3]=RxMessage.Data[3];
            buf[4]=RxMessage.Data[4];
					  buf[5]=RxMessage.Data[5];
            buf[6]=RxMessage.Data[6]; 
						WriteOneByte(MQ_Factor_A21, buf[1]); 
					  WriteOneByte(MQ_Factor_A22, buf[2]);	 
						WriteOneByte(MQ_Factor_B21, buf[3]); 
					  WriteOneByte(MQ_Factor_B22, buf[4]);	 
						WriteOneByte(MQ_Offset21, buf[5]); 
					  WriteOneByte(MQ_Offset22, buf[6]);
					
        }
       else if(RxMessage.Data[0]==7)//���ܺţ�7 �������뵥�ߣ�������������
        {
             Q_Factor_A3=(RxMessage.Data[1]<<8)+RxMessage.Data[2];
             Q_Factor_B3=(RxMessage.Data[3]<<8)+RxMessage.Data[4];									
             buf[1]=RxMessage.Data[1];
             buf[2]=RxMessage.Data[2];
					   buf[3]=RxMessage.Data[3];
             buf[4]=RxMessage.Data[4];
						 WriteOneByte(MQ_Factor_A31, buf[1]); 
					   WriteOneByte(MQ_Factor_A32, buf[2]);	    
					   WriteOneByte(MQ_Factor_B31, buf[3]); 
					   WriteOneByte(MQ_Factor_B32, buf[4]);	 				
        }
        else if(RxMessage.Data[0]==8)//���ܺţ�8  �������뵥�ߣ�������������
        {
             Q_Factor_A4=(RxMessage.Data[1]<<8)+RxMessage.Data[2];
             Q_Factor_B4=(RxMessage.Data[3]<<8)+RxMessage.Data[4];	
					   buf[1]=RxMessage.Data[1];
             buf[2]=RxMessage.Data[2];
					   buf[3]=RxMessage.Data[3];
             buf[4]=RxMessage.Data[4];
     				 WriteOneByte(MQ_Factor_A41, buf[1]); 
					   WriteOneByte(MQ_Factor_A42, buf[2]);	    
						 WriteOneByte(MQ_Factor_B41, buf[3]); 
					   WriteOneByte(MQ_Factor_B42, buf[4]); 

        }
        else if(RxMessage.Data[0]==9)//���ܺţ�9  ����������������	
        {
             minzerovalue=(RxMessage.Data[1]<<8)+RxMessage.Data[2];
             maxzerovalue=(RxMessage.Data[3]<<8)+RxMessage.Data[4];	
             buf[1]=RxMessage.Data[1];
             buf[2]=RxMessage.Data[2];
					   buf[3]=RxMessage.Data[3];
             buf[4]=RxMessage.Data[4];
					   WriteOneByte(Mminzerovalue11, buf[1]); 
					   WriteOneByte(Mminzerovalue12, buf[2]); 
						 WriteOneByte(Mmaxzerovalue11, buf[3]); 
					   WriteOneByte(Mmaxzerovalue12, buf[4]);
					
        }
        else if(RxMessage.Data[0]==10)//���ܺţ�10 ����������λ��������	
        {
             Offset_zero=(RxMessage.Data[1]<<8)+RxMessage.Data[2];
					   buf[1]=RxMessage.Data[1];
             buf[2]=RxMessage.Data[2];
						 WriteOneByte(MOffset_zero11, buf[1]); 
					   WriteOneByte(MOffset_zero12, buf[2]); 
					
        }
       else if(RxMessage.Data[0]==11)//���ܺţ�11  ѹ�������޷�ֵ����	
        {
             P_Limit_Min=((RxMessage.Data[1]<<8)+RxMessage.Data[2]);
             P_Limit_Max=((RxMessage.Data[3]<<8)+RxMessage.Data[4]);
					   buf[1]=RxMessage.Data[1];
             buf[2]=RxMessage.Data[2];
					   buf[3]=RxMessage.Data[3];
             buf[4]=RxMessage.Data[4];
						 WriteOneByte(MP_Limit_Min11, buf[1]); 
					   WriteOneByte(MP_Limit_Min12, buf[2]);      
						 WriteOneByte(MP_Limit_Max11, buf[3]); 
					   WriteOneByte(MP_Limit_Max12, buf[4]);
	 				

        }
       else if(RxMessage.Data[0]==12)//���ܺţ�12 ѹ���������ű�������	
        {
						P_Factor_A2=(RxMessage.Data[1]<<8)+RxMessage.Data[2];
						P_Factor_B2=(RxMessage.Data[3]<<8)+RxMessage.Data[4];
						P_Offset2=(RxMessage.Data[5]<<8)+RxMessage.Data[6];
					   buf[1]=RxMessage.Data[1];
             buf[2]=RxMessage.Data[2];
					   buf[3]=RxMessage.Data[3];
             buf[4]=RxMessage.Data[4];		
            
						 WriteOneByte(MP_Factor_A21, buf[1]); 
					   WriteOneByte(MP_Factor_A22, buf[2]);    

						 WriteOneByte(MP_Factor_B21, buf[3]); 
					   WriteOneByte(MP_Factor_B22, buf[4]);    

						 WriteOneByte(MP_Offset21, buf[5]); 
					   WriteOneByte(MP_Offset22, buf[6]);
					
        }
       else if(RxMessage.Data[0]==13)//���ܺţ�13 ѹ����������������	
        {     
             buf[1]=RxMessage.Data[1];
					  WriteOneByte(Msign_PorN, buf[1]);	 				 

             if(RxMessage.Data[1]==1)
              
             sign_Positive=1;
  
             else if(RxMessage.Data[1]==2)
               
             sign_Positive=-1; 
        }

       else if(RxMessage.Data[0]==21)//���ܺţ�21  ��оλ���޷�ֵ����
        {
        TS_position_min=((RxMessage.Data[1]<<8)+RxMessage.Data[2]);
        TS_position_max=((RxMessage.Data[3]<<8)+RxMessage.Data[4]);
						 buf[1]=RxMessage.Data[1];
             buf[2]=RxMessage.Data[2];
					   buf[3]=RxMessage.Data[3];
             buf[4]=RxMessage.Data[4];	
					
					
							if(TS_position_min>100)
							TS_position_min=TS_position_min-65536;
					    if(TS_position_max>100)
							TS_position_max=TS_position_max-65536;
      
						 WriteOneByte(MTS_position_min11, buf[1]); 
					   WriteOneByte(MTS_position_min12, buf[2]);  

						 WriteOneByte(MTS_position_max11, buf[3]); 
					   WriteOneByte(MTS_position_max12, buf[4]); 
							
        }

        else if(RxMessage.Data[0]==22)//���ܺţ�22  �����޷�ֵ����		
        {
        
           Current_limit_min=((RxMessage.Data[1]<<8)+RxMessage.Data[2]);

           Current_limit_max=((RxMessage.Data[3]<<8)+RxMessage.Data[4]);
					   buf[1]=RxMessage.Data[1];
             buf[2]=RxMessage.Data[2];
					   buf[3]=RxMessage.Data[3];
             buf[4]=RxMessage.Data[4];	
							if(Current_limit_min>100)
							Current_limit_min=Current_limit_min-65536;
					    if(Current_limit_max>100)
							Current_limit_max=Current_limit_max-65536;	
						WriteOneByte(MCurrent_limit_min11, buf[1]); 
					  WriteOneByte(MCurrent_limit_min12, buf[2]);  
						WriteOneByte(MCurrent_limit_max11, buf[3]); 
					  WriteOneByte(MCurrent_limit_max12, buf[4]);
							
        }
		 else if(RxMessage.Data[0]==23)//���ܺţ�23 ����PWM���ֱ��ʵ���
        {    PWM_FLAG=1;
					  
					   buf[0]=RxMessage.Data[1];
             buf[1]=RxMessage.Data[2];
					   buf[2]=RxMessage.Data[3];
				   	 buf[3]=RxMessage.Data[4];
						 WriteOneByte(M_PWM_asc1, buf[0]); 
						 WriteOneByte(M_PWM_asc2, buf[1]); 
					   WriteOneByte(M_PWM_psc1, buf[2]);   
						 WriteOneByte(M_PWM_psc2, buf[3]);  
			     	 ARR_pwm=( buf[0]<<8)+buf[1];
			    	 PSC_pwm=(buf[2]<<8)+buf[3];	
						 TIM1_PWM_Init(ARR_pwm,PSC_pwm);  //Duty 2000  ��Ƶϵ��Ϊ1
        }	
				 else if(RxMessage.Data[0]==25)//���ܺţ�25 ��о��Ȧ�����쳣����ֵ�趨   ƫ��ֵ
        {
					
              I_default=((RxMessage.Data[1]<<8)+RxMessage.Data[2]);
						  if(I_default>100)
							I_default=I_default-65536;
             buf[1]=RxMessage.Data[1];
             buf[2]=RxMessage.Data[2];
						 WriteOneByte(M_I_default11, buf[1]); 
					   WriteOneByte(M_I_default12, buf[2]);  
							
        }
				
				else if(RxMessage.Data[0]==26)//���ܺţ�26 ��о��λƯ�Ƴ���ֵ�趨  
        {
					   Spool_zero_default=(RxMessage.Data[1]<<8)+RxMessage.Data[2];
				  		if(Spool_zero_default>100)
					  	Spool_zero_default=Spool_zero_default-65536;
             buf[1]=RxMessage.Data[1];
             buf[2]=RxMessage.Data[2];
						 WriteOneByte(M_Spool_zero11, buf[1]);
					   WriteOneByte(M_Spool_zero12, buf[2]);
  						
        }
				else if(RxMessage.Data[0]==27)//���ܺţ�27 ��оλ���쳣����ֵ�趨    
        {
				     Spool_default=(RxMessage.Data[1]<<8)+RxMessage.Data[2];
						if(Spool_default>100)
					  Spool_default=Spool_default-65536;
             buf[1]=RxMessage.Data[1];
             buf[2]=RxMessage.Data[2];
						 WriteOneByte(M_Spool_default11, buf[1]); 
					   WriteOneByte(M_Spool_default12, buf[2]);						
        }
				
				
		/////////����   pi����  
				 else if(RxMessage.Data[0]==31)//���ܺţ�31 ѹ����PID��������P
        {
					P_close_loop_P=((RxMessage.Data[4]<<24)+(RxMessage.Data[3]<<16)+(RxMessage.Data[2]<<8)+RxMessage.Data[1]);
					P_close_loop_P=Int_To_Float(P_close_loop_P);
					buf[0]=RxMessage.Data[1];
					buf[1]=RxMessage.Data[2];
					buf[2]=RxMessage.Data[3];
				   	buf[3]=RxMessage.Data[4];
				  	WriteOneByte(MP_close_loop_P11, buf[0]); 
					WriteOneByte(MP_close_loop_P12, buf[1]);   
					WriteOneByte(MP_close_loop_P13, buf[2]);  
				    WriteOneByte(MP_close_loop_P14, buf[3]);	
					Flag_PIDchange_Pre=1;
        }
				
					 else if(RxMessage.Data[0]==32)//���ܺţ�32 ѹ����PID��������I
        {
					
				P_close_loop_I=Int_To_Float((RxMessage.Data[4]<<24)+(RxMessage.Data[3]<<16)+(RxMessage.Data[2]<<8)+RxMessage.Data[1]);
             buf[0]=RxMessage.Data[1];
             buf[1]=RxMessage.Data[2];
					   buf[2]=RxMessage.Data[3];
				   	 buf[3]=RxMessage.Data[4];
						 WriteOneByte(MP_close_loop_I11, buf[0]); 
					   WriteOneByte(MP_close_loop_I12, buf[1]);   
						 WriteOneByte(MP_close_loop_I13, buf[2]);  
				     WriteOneByte(MP_close_loop_I14, buf[3]); 
						 Flag_PIDchange_Pre=1;
        }
				
					else if(RxMessage.Data[0]==33)//���ܺţ�33������PID��������P
        {
					
				     Q_close_loop_P=((RxMessage.Data[4]<<24)+(RxMessage.Data[3]<<16)+(RxMessage.Data[2]<<8)+RxMessage.Data[1]);
					Q_close_loop_P=Int_To_Float(Q_close_loop_P);
             buf[0]=RxMessage.Data[1];
             buf[1]=RxMessage.Data[2];
					   buf[2]=RxMessage.Data[3];
				   	 buf[3]=RxMessage.Data[4];
						 WriteOneByte(MQ_close_loop_P11, buf[0]); 
					   WriteOneByte(MQ_close_loop_P12, buf[1]);   
						 WriteOneByte(MQ_close_loop_P13, buf[2]);  
				     WriteOneByte(MQ_close_loop_P14, buf[3]); 
						 Flag_PIDchange_Flow=1;
        }

				 else if(RxMessage.Data[0]==34)//���ܺţ�34 ������PID��������I
        {
					
             Q_close_loop_I=((RxMessage.Data[4]<<24)+(RxMessage.Data[3]<<16)+(RxMessage.Data[2]<<8)+RxMessage.Data[1]);
					Q_close_loop_I=Int_To_Float(Q_close_loop_I);
             buf[0]=RxMessage.Data[1];
             buf[1]=RxMessage.Data[2];
					   buf[2]=RxMessage.Data[3];
				   	 buf[3]=RxMessage.Data[4];
						 WriteOneByte(MQ_close_loop_I11, buf[0]); 
					   WriteOneByte(MQ_close_loop_I12, buf[1]);   
						 WriteOneByte(MQ_close_loop_I13, buf[2]);  
				     WriteOneByte(MQ_close_loop_I14, buf[3]); 
	 				   Flag_PIDchange_Flow=1;
        }
				
				else if(RxMessage.Data[0]==35)//���ܺţ�35 ������P
        {
					float_test=0.008;					
//					test_can
        I_close_loop_P=((RxMessage.Data[4]<<24)+(RxMessage.Data[3]<<16)+(RxMessage.Data[2]<<8)+RxMessage.Data[1]);
			I_close_loop_P=Int_To_Float(I_close_loop_P);
             buf[0]=RxMessage.Data[1];
             buf[1]=RxMessage.Data[2];
					   buf[2]=RxMessage.Data[3];
				   	   buf[3]=RxMessage.Data[4];
					   WriteOneByte(MI_close_loop_P11, buf[0]); 
					   WriteOneByte(MI_close_loop_P12, buf[1]);   
					   WriteOneByte(MI_close_loop_P13, buf[2]);  
				       WriteOneByte(MI_close_loop_P14, buf[3]); 
					   Flag_PIDchange_Current=1;
        }
				
				else if(RxMessage.Data[0]==36)//���ܺţ�36 ������I
        {
					
        I_close_loop_I=Int_To_Float((RxMessage.Data[4]<<24)+(RxMessage.Data[3]<<16)+(RxMessage.Data[2]<<8)+RxMessage.Data[1]);
             buf[0]=RxMessage.Data[1];
             buf[1]=RxMessage.Data[2];
					   buf[2]=RxMessage.Data[3];
				   	 buf[3]=RxMessage.Data[4];
						 WriteOneByte(MI_close_loop_I11, buf[0]); 
					   WriteOneByte(MI_close_loop_I12, buf[1]);   
						 WriteOneByte(MI_close_loop_I13, buf[2]);  
				     WriteOneByte(MI_close_loop_I14, buf[3]);
						 Flag_PIDchange_Current=1;
        }		
				
				
				else if(RxMessage.Data[0]==37)//���ܺţ�37 �ڲ������ź�����
        {
					
        P_Target=Int_To_Float((RxMessage.Data[4]<<24)+(RxMessage.Data[3]<<16)+(RxMessage.Data[2]<<8)+RxMessage.Data[1]);
				Q_Target=P_Target;
				I_Target=Q_Target;	
             buf[0]=RxMessage.Data[1];
             buf[1]=RxMessage.Data[2];
					   buf[2]=RxMessage.Data[3];
				   	 buf[3]=RxMessage.Data[4];
						 WriteOneByte(M_inputvalue1, buf[0]); 
					   WriteOneByte(M_inputvalue2, buf[1]);   
						 WriteOneByte(M_inputvalue3, buf[2]);  
				     WriteOneByte(M_inputvalue4, buf[3]);
        }	
				 else if(RxMessage.Data[0]==38)//���ܺţ�38 �ָ�����ֵ
        {
             buf[0]=1;
						 WriteOneByte(M_initial, buf[0]); 
						 WriteOneByte(M_Spool_default11,0); 
					   WriteOneByte(M_Spool_default12,5);   
						 WriteOneByte(M_Spool_zero11, 0);  
				     WriteOneByte(M_Spool_zero12, 5);
						 WriteOneByte(M_I_default11, 0);  
				     WriteOneByte(M_I_default12, 5);
        }	
				else if(RxMessage.Data[0]==39)//���ܺţ�39  ������Ƭ��
        {
					CPU_restart=1;
        }	
		else if(RxMessage.Data[0]==40)//���ܺţ�39  ������Ƭ��
        {
					CPU_restart=1;
        }	
		
		
		
		else if(RxMessage.Data[0]==50)//���ܺţ�50 ���ģʽ����
				{
					     
					
						   AI1type=RxMessage.Data[1];
						   AI2type=RxMessage.Data[2];
						   AI3type=RxMessage.Data[3];
						   AI4type=RxMessage.Data[4];
					
			
						Input_type=2;
		
					
					if(AI1type==1)
						Input_P_type=1;
					if(AI1type==2)
						Input_P_type=2;
					
					if(AI2type==1)
						Input_P_type=3;
					if(AI2type==2)
						Input_P_type=4;
					if(AI2type==3)
						Input_P_type=5;
					if(AI2type==4)
						Input_P_type=6;
					
					if(AI3type==1)
						Input_Q_type=1;
					if(AI3type==2)
						Input_Q_type=2;
					
					if(AI4type==1)
						Input_Q_type=3;
					if(AI4type==2)
						Input_Q_type=4;
					if(AI4type==3)
						Input_Q_type=5;
					if(AI4type==4)
						Input_Q_type=6;
					
					
						   buf[0]=RxMessage.Data[1];
						   buf[1]=RxMessage.Data[2];
						   buf[2]=RxMessage.Data[3];
						   buf[3]=RxMessage.Data[4];
						   WriteOneByte(AI1type_adr, buf[0]); 
						   WriteOneByte(AI2type_adr, buf[1]);   
						   WriteOneByte(AI3type_adr, buf[2]);  
						   WriteOneByte(AI4type_adr, buf[3]); 
				}	
		else if(RxMessage.Data[0]==51)//���ܺţ�51 ǿ������
		{
				Power_enforce=RxMessage.Data[1];
		}	
		}
		else if(ID==CANID_ASK)  //ѯ��ָ��
				{  
				if(RxMessage.Data[0]==1)  
						{	
						
						CAN_ASK_buf[0]=1;
						
						CAN_ASK_buf[1]=ReadOneByte(M_runmode); 
						if(CAN_ASK_buf[1]==1)
						{
						CAN_ASK_buf[2]=ReadOneByte(MCurrent_OpenPwm11); 
						CAN_ASK_buf[3]=ReadOneByte(MCurrent_OpenPwm12); 
						CAN_ASK_buf[4]=ReadOneByte(MCurrent_OpenPwm13); 
						CAN_ASK_buf[5]=ReadOneByte(MCurrent_OpenPwm14); 							
						}
						else if(CAN_ASK_buf[1]==2)
						{
						CAN_ASK_buf[2]=ReadOneByte(MCurrent_CloseValue_Set11); 
						CAN_ASK_buf[3]=ReadOneByte(MCurrent_CloseValue_Set12);
						CAN_ASK_buf[4]=ReadOneByte(MCurrent_CloseValue_Set13); 
						CAN_ASK_buf[5]=ReadOneByte(MCurrent_CloseValue_Set14); 							
						}
						else if(CAN_ASK_buf[1]==4)
						{
						CAN_ASK_buf[2]=ReadOneByte(MSpool_CloseValue_Set11); 
						CAN_ASK_buf[3]=ReadOneByte(MSpool_CloseValue_Set12); 						
						}
						else if(CAN_ASK_buf[1]==6)
						{
						CAN_ASK_buf[2]=ReadOneByte(MP_CloseValue_Set11); 
						CAN_ASK_buf[3]=ReadOneByte(MP_CloseValue_Set12); 						
						}	
					  CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);
						}
				else if(RxMessage.Data[0]==2)   //���ܺţ�2  ����������������
							{
					    	CAN_ASK_buf[0]=RxMessage.Data[0];
								CAN_ASK_buf[1]=AI1type; 
								CAN_ASK_buf[2]=AI2type; 
								CAN_ASK_buf[3]=AI3type; 
								CAN_ASK_buf[4]=AI4type; 
				        CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);
							}

				else if(RxMessage.Data[0]==3)  //���ܺţ�3  ��оλ��ģ�����������   qt û���ú�
						{

					     	CAN_ASK_buf[0]=RxMessage.Data[0];					 
								CAN_ASK_buf[1]=ReadOneByte(MQ_Factor_A11); 
								CAN_ASK_buf[2]=ReadOneByte(MQ_Factor_A12);   
								CAN_ASK_buf[3]=ReadOneByte(MQ_Factor_B11); 
								CAN_ASK_buf[4]=ReadOneByte(MQ_Factor_B12);   
								CAN_ASK_buf[5]=ReadOneByte(MQ_Offset11); 
								CAN_ASK_buf[6]=ReadOneByte(MQ_Offset12); 
				    		CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);
						}
				else if(RxMessage.Data[0]==4)//���ܺţ�4  ѹ�����ģ�����������
						{
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MP_Factor_A11); 
						CAN_ASK_buf[2]=ReadOneByte(MP_Factor_A12); 
						CAN_ASK_buf[3]=ReadOneByte(MP_Factor_B11); 
						CAN_ASK_buf[4]=ReadOneByte(MP_Factor_B12); 
						CAN_ASK_buf[5]=ReadOneByte(MP_Offset11); 
						CAN_ASK_buf[6]=ReadOneByte(MP_Offset12); 
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);
						}
				else if(RxMessage.Data[0]==5)//���ܺţ�5  ���������޷�ֵ����	
						{          
						CAN_ASK_buf[0]=RxMessage.Data[0];
				  	CAN_ASK_buf[1]=ReadOneByte(MQ_Limit_Min11); 
						CAN_ASK_buf[2]=ReadOneByte(MQ_Limit_Min12); 
						CAN_ASK_buf[3]=ReadOneByte(MQ_Limit_Max11); 
						CAN_ASK_buf[4]=ReadOneByte(MQ_Limit_Max12);
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);
						}
				else if(RxMessage.Data[0]==6)//���ܺţ�6  �����������ű�������
						{
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MQ_Factor_A21); 
						CAN_ASK_buf[2]=ReadOneByte(MQ_Factor_A22); 
						CAN_ASK_buf[3]=ReadOneByte(MQ_Factor_B21); 
						CAN_ASK_buf[4]=ReadOneByte(MQ_Factor_B22); 
						CAN_ASK_buf[5]=ReadOneByte(MQ_Offset21); 
						CAN_ASK_buf[6]=ReadOneByte(MQ_Offset22); 
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);
						}
				
				else if(RxMessage.Data[0]==7)//���ܺţ�7 �������뵥�ߣ�������������
						{
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MQ_Factor_A31); 
						CAN_ASK_buf[2]=ReadOneByte(MQ_Factor_A32); 
						CAN_ASK_buf[3]=ReadOneByte(MQ_Factor_B31); 
						CAN_ASK_buf[4]=ReadOneByte(MQ_Factor_B32); 
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);

						}
				else if(RxMessage.Data[0]==8)//���ܺţ�8  �������뵥�ߣ�������������
						{
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MQ_Factor_A41); 
						CAN_ASK_buf[2]=ReadOneByte(MQ_Factor_A42); 
						CAN_ASK_buf[3]=ReadOneByte(MQ_Factor_B41); 
						CAN_ASK_buf[4]=ReadOneByte(MQ_Factor_B42); 
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);

						}
				else if(RxMessage.Data[0]==9)//���ܺţ�9  ����������������	
						{
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(Mminzerovalue11); 
						CAN_ASK_buf[2]=ReadOneByte(Mminzerovalue12); 
						CAN_ASK_buf[3]=ReadOneByte(Mmaxzerovalue11); 
						CAN_ASK_buf[4]=ReadOneByte(Mmaxzerovalue12); 
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);

						}
	  		else if(RxMessage.Data[0]==10)//���ܺţ�10 ����������λ��������	
						{
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MOffset_zero11); 
						CAN_ASK_buf[2]=ReadOneByte(MOffset_zero12); 
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);

						}
		  	else if(RxMessage.Data[0]==11)//���ܺţ�11  ѹ�������޷�ֵ����	
						{
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MP_Limit_Min11); 
						CAN_ASK_buf[2]=ReadOneByte(MP_Limit_Min12); 
						CAN_ASK_buf[3]=ReadOneByte(MP_Limit_Max11); 
						CAN_ASK_buf[4]=ReadOneByte(MP_Limit_Max12);
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);	

						}
			  else if(RxMessage.Data[0]==12)//���ܺţ�12 ѹ���������ű�������	
						{
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MP_Factor_A21); 
						CAN_ASK_buf[2]=ReadOneByte(MP_Factor_A22); 
						CAN_ASK_buf[3]=ReadOneByte(MP_Factor_B21); 
						CAN_ASK_buf[4]=ReadOneByte(MP_Factor_B22);
						CAN_ASK_buf[5]=ReadOneByte(MP_Offset21); 
						CAN_ASK_buf[6]=ReadOneByte(MP_Offset22); 
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);	

						}
				else if(RxMessage.Data[0]==13)//���ܺţ�13 ѹ����������������	
						{
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(Msign_PorN); 
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);	
						}
			  else if(RxMessage.Data[0]==21)//���ܺţ�21  ��оλ���޷�ֵ����
				{
				    CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MTS_position_min11); 
						CAN_ASK_buf[2]=ReadOneByte(MTS_position_min12); 
						CAN_ASK_buf[3]=ReadOneByte(MTS_position_max11); 
						CAN_ASK_buf[4]=ReadOneByte(MTS_position_max12); 
 						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);

				}
       else if(RxMessage.Data[0]==22)//���ܺţ�22  �����޷�ֵ����		
    		{
				    CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MCurrent_limit_min11); 
						CAN_ASK_buf[2]=ReadOneByte(MCurrent_limit_min12); 
						CAN_ASK_buf[3]=ReadOneByte(MCurrent_limit_max11); 
						CAN_ASK_buf[4]=ReadOneByte(MCurrent_limit_max12); 
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);

				}		
									 else if(RxMessage.Data[0]==23)//���ܺţ�����PWM����
				{
				    u8 i=0;
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(M_PWM_asc1); 
						CAN_ASK_buf[2]=ReadOneByte(M_PWM_asc2); 
						CAN_ASK_buf[3]=ReadOneByte(M_PWM_psc1); 
						CAN_ASK_buf[4]=ReadOneByte(M_PWM_psc2); 
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);		
				}
				
			 else if(RxMessage.Data[0]==25)//���ܺţ�25 ��о��Ȧ�����쳣����ֵ�趨   ƫ��ֵ
        {
					
            CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(M_I_default11); 
						CAN_ASK_buf[2]=ReadOneByte(M_I_default12); 
	      		CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);

        }	
					else if(RxMessage.Data[0]==26)//���ܺţ�26 ��о��λƯ�Ƴ���ֵ�趨  
        {
					  CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(M_Spool_zero11); 
						CAN_ASK_buf[2]=ReadOneByte(M_Spool_zero12); 
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);

        }		
				 else if(RxMessage.Data[0]==27)//���ܺţ�27 ��оλ���쳣����ֵ�趨  
        {
					  CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(M_Spool_default11); 
						CAN_ASK_buf[2]=ReadOneByte(M_Spool_default12); 
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);

        }	
				else if(RxMessage.Data[0]==31)//���ܺţ�31 ѹ����PID��������P
				{
				
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MP_close_loop_P11); 
						CAN_ASK_buf[2]=ReadOneByte(MP_close_loop_P12); 
						CAN_ASK_buf[3]=ReadOneByte(MP_close_loop_P13); 
						CAN_ASK_buf[4]=ReadOneByte(MP_close_loop_P14); 
    				CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);

				}				
				
				else if(RxMessage.Data[0]==32)//���ܺţ�32 ѹ����PID��������I
				{
				
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MP_close_loop_I11); 
						CAN_ASK_buf[2]=ReadOneByte(MP_close_loop_I12); 
						CAN_ASK_buf[3]=ReadOneByte(MP_close_loop_I13); 
						CAN_ASK_buf[4]=ReadOneByte(MP_close_loop_I14); 
    				CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);	
					
				}				
				else if(RxMessage.Data[0]==33)//���ܺţ�33������PID��������P
				{
				
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MQ_close_loop_P11); 
						CAN_ASK_buf[2]=ReadOneByte(MQ_close_loop_P12); 
						CAN_ASK_buf[3]=ReadOneByte(MQ_close_loop_P13); 
						CAN_ASK_buf[4]=ReadOneByte(MQ_close_loop_P14); 
    				CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);
					
				}			
				else if(RxMessage.Data[0]==34)//���ܺţ�34 ������PID��������I
				{
				
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MQ_close_loop_I11); 
						CAN_ASK_buf[2]=ReadOneByte(MQ_close_loop_I12); 
						CAN_ASK_buf[3]=ReadOneByte(MQ_close_loop_I13); 
						CAN_ASK_buf[4]=ReadOneByte(MQ_close_loop_I14); 
        		CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);							
				}
				else if(RxMessage.Data[0]==35)//���ܺţ�35 ������P
				{
					  
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MI_close_loop_P11); 
						CAN_ASK_buf[2]=ReadOneByte(MI_close_loop_P12); 
						CAN_ASK_buf[3]=ReadOneByte(MI_close_loop_P13); 
						CAN_ASK_buf[4]=ReadOneByte(MI_close_loop_P14); 
	  				CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);	
					
				}
				 else if(RxMessage.Data[0]==36)//���ܺţ�36 ������I
				{
				    u8 i=0;
						CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=ReadOneByte(MI_close_loop_I11); 
						CAN_ASK_buf[2]=ReadOneByte(MI_close_loop_I12); 
						CAN_ASK_buf[3]=ReadOneByte(MI_close_loop_I13); 
						CAN_ASK_buf[4]=ReadOneByte(MI_close_loop_I14); 
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);		
				}
				 else if(RxMessage.Data[0]==40)//���ܺţ�40 ��ʾPWM�ֱ���	
				{				     					
					    CAN_ASK_buf[0]=RxMessage.Data[0];
						CAN_ASK_buf[1]=((arr_flag&0XFF00)>>8);
						CAN_ASK_buf[2]=(arr_flag&0XFF);
						CAN_ASK_buf[3]=((psc_flag&0XFF00)>>8);
						CAN_ASK_buf[4]=(psc_flag&0XFF);
						CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);
				}
}

	else if(ID==CANID_ASKstats)  //����״̬ѯ�ʷ���id
				{
					if(RxMessage.Data[0]==1)     //����״̬����  
				 {
	 
					CAN_ASK_buf[0]=RxMessage.Data[0];
					CAN_ASK_buf[1]=Runmode;
					CAN1_Send_Msg(CANID_ASKstats,CAN_ASK_buf,8);
					}
			 else if(RxMessage.Data[0]==2)
					{
					CAN_ASK_buf[0]=RxMessage.Data[0];
					CAN_ASK_buf[1]=Input_P_type;
					CAN_ASK_buf[2]=Input_Q_type;
					CAN1_Send_Msg(CANID_ASKstats,CAN_ASK_buf,8);
					}
				else  if(RxMessage.Data[0]==3)
					{
					CAN_ASK_buf[0]=RxMessage.Data[0];
					CAN_ASK_buf[1]=Input_P_type;
					CAN_ASK_buf[2]=Input_Q_type;
					CAN1_Send_Msg(CANID_ASKstats,CAN_ASK_buf,8);
					}

				else if(RxMessage.Data[0]==3)
					{
					CAN_ASK_buf[0]=RxMessage.Data[0];
					CAN_ASK_buf[1]=(P_Factor_A1>>8)&0x0FF;
					CAN_ASK_buf[2]=P_Factor_A1&0x0FF;
					CAN_ASK_buf[3]=(P_Factor_B1>>8)&0x0FF;
					CAN_ASK_buf[4]=P_Factor_B1&0x0FF;
					CAN_ASK_buf[5]=(P_Offset1>>8)&0x0FF;
					CAN_ASK_buf[6]=P_Offset1&0x0FF;
					CAN1_Send_Msg(CANID_ASKstats,CAN_ASK_buf,8);
					}
				else if(RxMessage.Data[0]==4)
					{
					CAN_ASK_buf[0]=RxMessage.Data[0];
					CAN_ASK_buf[1]=(P_Factor_A1>>8)&0x0FF;
					CAN_ASK_buf[2]=P_Factor_A1&0x0FF;
					CAN_ASK_buf[3]=(P_Factor_B1>>8)&0x0FF;
					CAN_ASK_buf[4]=P_Factor_B1&0x0FF;
					CAN_ASK_buf[5]=(P_Offset1>>8)&0x0FF;
					CAN_ASK_buf[6]=P_Offset1&0x0FF;
					CAN1_Send_Msg(CANID_ASKstats,CAN_ASK_buf,8);
					}
				else if(RxMessage.Data[0]==5)
					{
					CAN_ASK_buf[0]=RxMessage.Data[0];
					CAN_ASK_buf[1]=(Q_Factor_A1>>8)&0x0FF;
					CAN_ASK_buf[2]=Q_Factor_A1&0x0FF;
					CAN_ASK_buf[3]=(Q_Factor_B1>>8)&0x0FF;
					CAN_ASK_buf[4]=Q_Factor_B1&0x0FF;
					CAN_ASK_buf[5]=(Q_Offset1>>8)&0x0FF;
					CAN_ASK_buf[6]=Q_Offset1&0x0FF;
					CAN1_Send_Msg(CANID_ASKstats,CAN_ASK_buf,8);
					}
				else if(RxMessage.Data[0]==6)
					{
					CAN_ASK_buf[0]=RxMessage.Data[0];
					CAN_ASK_buf[1]=(Q_Factor_A2>>8)&0x0FF;
					CAN_ASK_buf[2]=Q_Factor_A2&0x0FF;
					CAN_ASK_buf[3]=(Q_Factor_B2>>8)&0x0FF;
					CAN_ASK_buf[4]=Q_Factor_B2&0x0FF;
					CAN_ASK_buf[5]=(Q_Offset2>>8)&0x0FF;
					CAN_ASK_buf[6]=Q_Offset2&0x0FF;
					CAN1_Send_Msg(CANID_ASKstats,CAN_ASK_buf,8);
					}
			
				else if(RxMessage.Data[0]==7)
					{

					CAN_ASK_buf[0]=RxMessage.Data[0];
					CAN_ASK_buf[1]=(Q_Factor_A3>>8)&0x0FF;
					CAN_ASK_buf[2]=Q_Factor_A3&0x0FF;
					CAN_ASK_buf[3]=(Q_Factor_B3>>8)&0x0FF;
					CAN_ASK_buf[4]=Q_Factor_B3&0x0FF;
					CAN1_Send_Msg(CANID_ASKstats,CAN_ASK_buf,8);
					}
				else if(RxMessage.Data[0]==8)
					{                
					CAN_ASK_buf[0]=RxMessage.Data[0];
					CAN_ASK_buf[1]=(Q_Factor_A4>>8)&0x0FF;
					CAN_ASK_buf[2]=Q_Factor_A4&0x0FF;
					CAN_ASK_buf[3]=(Q_Factor_B4>>8)&0x0FF;
					CAN_ASK_buf[4]=Q_Factor_B4&0x0FF;
					CAN1_Send_Msg(CANID_ASKstats,CAN_ASK_buf,8);
					}
				else if(RxMessage.Data[0]==9)
					{
					CAN_ASK_buf[0]=RxMessage.Data[0];
					CAN_ASK_buf[1]=(minzerovalue>>8)&0x0FF;
					CAN_ASK_buf[2]=minzerovalue&0x0FF;
					CAN_ASK_buf[3]=(maxzerovalue>>8)&0x0FF;
					CAN_ASK_buf[4]=maxzerovalue&0x0FF;
					CAN1_Send_Msg(CANID_ASKstats,CAN_ASK_buf,8);
					}
					else if(RxMessage.Data[0]==10)
					{
					CAN_ASK_buf[0]=RxMessage.Data[0];
					CAN_ASK_buf[1]=(Offset_zero>>8)&0x0FF;
					CAN_ASK_buf[2]= Offset_zero&0x0FF;
					CAN1_Send_Msg(CANID_ASKstats,CAN_ASK_buf,8);
					}
					else if(RxMessage.Data[0]==11)
					{
					CAN_ASK_buf[0]=RxMessage.Data[0];
					CAN_ASK_buf[1]=(P_Limit_Min>>8)&0x0FF;
					CAN_ASK_buf[2]= P_Limit_Max&0x0FF;
					CAN1_Send_Msg(CANID_ASK,CAN_ASK_buf,8);
					}
				else	if(RxMessage.Data[0]==12)
					{
					CAN_ASK_buf[0]=RxMessage.Data[0];
					CAN_ASK_buf[1]=(P_Factor_A2>>8)&0x0FF;
					CAN_ASK_buf[2]= P_Factor_A2&0x0FF;
					CAN_ASK_buf[3]=(P_Factor_B2>>8)&0x0FF;
					CAN_ASK_buf[4]= P_Factor_B2&0x0FF;
					CAN_ASK_buf[5]=(P_Offset2>>8)&0x0FF;
					CAN_ASK_buf[6]=P_Offset2&0x0FF;
					CAN1_Send_Msg(CANID_ASKstats,CAN_ASK_buf,8);
					}
				else	if(RxMessage.Data[0]==13)
					{
					CAN_ASK_buf[0]=RxMessage.Data[0];
						 if(sign_Positive>0)
							CAN_ASK_buf[1]=1;

						 else if(sign_Positive<0)

							CAN_ASK_buf[1]=2;
							CAN1_Send_Msg(CANID_ASKstats,CAN_ASK_buf,8);
					}

					
					
						} 
				else if(ID==CAN_IAPID)  //IAP ����
				{
					 Value1=(RxMessage.Data[0]<<24)|(RxMessage.Data[1]<<16)|(RxMessage.Data[2]<<8)|(RxMessage.Data[3]);
					 Value2=(RxMessage.Data[4]<<24)|(RxMessage.Data[5]<<16)|(RxMessage.Data[6]<<8)|(RxMessage.Data[7]);
					 if(((Value1==CANID_SET))&&(Value2==IAPKEY))
					 {
						 	FLASH_Unlock();
					    FLASH_EraseSector(STM32F4FLASH_GetFlashSector(EXE_APP_FLAG), VoltageRange_3) ;//��IAPKEY����������´ν���IAP
						    FLASH_Lock();
						 CPU_restart=1;//������Ƭ��
					 }
				}
	 CAN_ClearITPendingBit(CAN1,CAN_IT_FMP0); 
}

//void CAN1_RX0_IRQHandler(void)
//{
//	
//	
//  	CanRxMsg RxMessage;
//	int i=0;
//    CAN_Receive(CAN1, 0, &RxMessage);
//	for(i=0;i<8;i++)
//    P_Factor_A2=0;
//	CAN_ClearITPendingBit(CAN1,CAN_IT_FMP0); 

//}


//�жϷ�����
void CAN2_RX0_IRQHandler (void)//�����������յ������� 
{
  	CanRxMsg RxMessage;

	  CAN_Receive(CAN2, 0, &RxMessage);
	  CAN_ClearITPendingBit(CAN2,CAN_IT_FMP0); 
}


//can����һ������(�̶���ʽ:IDΪ0X12,��׼֡,����֡)	
//len:���ݳ���(���Ϊ8)				     
//msg:����ָ��,���Ϊ8���ֽ�.
//����ֵ:0,�ɹ�;
//		 ����,ʧ��;
 int CAN1_Send_Msg(unsigned int ID, int* msg,unsigned char len)
{	
  unsigned char mbox;
  u16 i=0;
  CanTxMsg TxMessage;
  TxMessage.StdId=0x012;	 // ��׼��ʶ��Ϊ0
  TxMessage.ExtId=ID;	 // ������չ��ʾ����29λ��
  TxMessage.IDE=CAN_ID_EXT;		  // ʹ����չ��ʶ��
  TxMessage.RTR=CAN_RTR_DATA;		  // ��Ϣ����Ϊ����֡��һ֡8λ
  TxMessage.DLC=len;							 // ������֡��Ϣ
  for(i=0;i<len;i++)
  TxMessage.Data[i]=msg[i];				 // ��һ֡��Ϣ          
  mbox= CAN_Transmit(CAN1, &TxMessage);   
  i=0;
//  while((CAN_TransmitStatus(CAN1, mbox)==CAN_TxStatus_Failed)&&(i<0XFFF))i++;	//�ȴ����ͽ���
//  if(i>=0XFFF)return 1;
//  return 0;	
	while(i<0xFFF)
	{
		if(CAN_TransmitStatus(CAN1, mbox)==CAN_TxStatus_Ok)break;
		i++;
	}	

}

//can����һ������(�̶���ʽ:IDΪ0X12,��׼֡,����֡)	
//len:���ݳ���(���Ϊ8)				     
//msg:����ָ��,���Ϊ8���ֽ�.
//����ֵ:0,�ɹ�;
//		 ����,ʧ��;
unsigned char CAN2_Send_Msg(unsigned int ID,unsigned char* msg,unsigned char len)
{	
  unsigned char mbox;
  u16 i=0;
  CanTxMsg TxMessage;
  TxMessage.StdId=0x012;	 // ��׼��ʶ��Ϊ0
  TxMessage.ExtId=ID;	 // ������չ��ʾ����29λ��
  TxMessage.IDE=CAN_ID_EXT;		  // ʹ����չ��ʶ��
  TxMessage.RTR=CAN_RTR_DATA;		  // ��Ϣ����Ϊ����֡��һ֡8λ
  TxMessage.DLC=len;							 // ������֡��Ϣ
  for(i=0;i<len;i++)
  TxMessage.Data[i]=msg[i];				 // ��һ֡��Ϣ          
  mbox= CAN_Transmit(CAN2, &TxMessage);   
  i=0;
//  while((CAN_TransmitStatus(CAN2, mbox)==CAN_TxStatus_Failed)&&(i<0XFFF))i++;	//�ȴ����ͽ���
//  if(i>=0XFFF)return 1;
	while(i<0xFFF)
	{
		if(CAN_TransmitStatus(CAN2, mbox)==CAN_TxStatus_Ok)break;
		i++;
	}	
//  return 0;		

}


//can�ڽ������ݲ�ѯ
//buf:���ݻ�����;	 
//����ֵ:0,�����ݱ��յ�;
//		 ����,���յ����ݳ���;
u8 CAN1_Receive_Msg(u8 *buf)
{		   		   
 	u32 i;
	CanRxMsg RxMessage;
    if( CAN_MessagePending(CAN1,CAN_FIFO0)==0)return 0;		//û�н��յ�����,ֱ���˳� 
    CAN_Receive(CAN1, CAN_FIFO0, &RxMessage);//��ȡ����	
    for(i=0;i<RxMessage.DLC;i++)
    can_test[i]=RxMessage.Data[i]+1;  
	return RxMessage.DLC;	
}






/**
  * @brief  ��������д��ָ����ַ��Flash�� ��
  * @param  Address Flash��ʼ��ַ��
  * @param  Data ���ݴ洢����ʼ��ַ��
  * @param  DataNum �����ֽ�����
  * @retval ������д״̬��
  */
	u32 STM32F4FLASH_GetFlashSector(u32 addr)
{
	if(addr < ADDR_FLASH_SECTOR_1)
		return FLASH_Sector_0;
	else if(addr < ADDR_FLASH_SECTOR_2)
		return FLASH_Sector_1;
	else if(addr < ADDR_FLASH_SECTOR_3)
		return FLASH_Sector_2;
	else if(addr < ADDR_FLASH_SECTOR_4)
		return FLASH_Sector_3;
	else if(addr < ADDR_FLASH_SECTOR_5)
		return FLASH_Sector_4;
	else if(addr < ADDR_FLASH_SECTOR_6)
		return FLASH_Sector_5;
	else if(addr < ADDR_FLASH_SECTOR_7)
		return FLASH_Sector_6;
	else if(addr < ADDR_FLASH_SECTOR_8)
		return FLASH_Sector_7;
	else if(addr < ADDR_FLASH_SECTOR_9)
		return FLASH_Sector_8;
	else if(addr < ADDR_FLASH_SECTOR_10)
		return FLASH_Sector_9;
	else if(addr < ADDR_FLASH_SECTOR_11)
		return FLASH_Sector_10;
	else return FLASH_Sector_11;
	
}
FLASH_Status CAN_BOOT_ProgramDatatoFlash(uint32_t StartAddress,uint8_t *pData,uint32_t DataNum) 
{
	FLASH_Status FLASHStatus = FLASH_COMPLETE;

	uint32_t i;

	if(StartAddress<EXE_APP_FLAG)
		{
		return FLASH_ERROR_PROGRAM;
	  }
   /* Clear All pending flags */
  FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGAERR|FLASH_FLAG_PGPERR|FLASH_FLAG_PGSERR | FLASH_FLAG_WRPERR);	
	
  for(i=0;i<(DataNum>>2);i++)
	{
    FLASHStatus = FLASH_ProgramWord(StartAddress, *((uint32_t*)pData));
		if (FLASHStatus == FLASH_COMPLETE)
			{
      StartAddress += 4;
      pData += 4;
      }
			else
		{ 
			return FLASHStatus;
    }
  }
	return	FLASHStatus;
}
































