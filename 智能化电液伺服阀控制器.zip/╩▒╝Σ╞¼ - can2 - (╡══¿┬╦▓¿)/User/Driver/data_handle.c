#include "main.h"
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
extern int duty_flag;
extern uint8_t AI1type,AI2type,AI3type,AI4type;//ģ�����������ͣ�����ģ�����������Ͷ���
extern float duty_now;     //ʵ����Ȧ������Ӧ��ռ�ձ�
float Adc_V[10]={0.0};	     
u8  ADC_i=0;
u32 ADC_S8[10]={0};
extern u8 Init_error_flag;

void Get_Adcvalue(float *Adcvalue)//�����е�ADCֵת��Ϊ�ٷ���*100
{

	
//	if(Init_error_flag==6)
//	{
//		ADC_S8[5]=ADC_Proc_Value(5);
//		Adc_V[5]=(float)ADC_S8[5]*0.00081;	
//		ADC_S8[1]=ADC_Proc_Value(1);
//		Adc_V[1]=(float)ADC_S8[1]*0.00081;
//		
//	}
//	else
	{
		for(ADC_i=0; ADC_i<ADC_SAMPLE_CNUM;ADC_i++)
            {
				ADC_S8[ADC_i]=ADC_Proc_Value(ADC_i);
				Adc_V[ADC_i]=(float)ADC_S8[ADC_i]*0.00081;	
            }	
	}
	
	      			
						
						
        						

						
			if(duty_flag==1)      
				{
				*Adcvalue=0.6777*(-324.9*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]+2137.9*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]-5604.3*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]+7478.5*Adc_V[0]*Adc_V[0]*Adc_V[0]-5384.7*Adc_V[0]*Adc_V[0]+2083.7*Adc_V[0]-284.2);   //XQ����������3.3ŷ��(FIR��ͨ�˲�125HZ)
//				*Adcvalue=-9.9*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]+110.7*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]-491*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]+1098.9*Adc_V[0]*Adc_V[0]*Adc_V[0]-1310.7*Adc_V[0]*Adc_V[0]+840.3*Adc_V[0]-173.7;   //XQ����������3.3ŷ��(�����С��ֵ�˲�)
//				 *Adcvalue=-4.3167*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]+49.5490*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]-225.3179*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]+517.0911*Adc_V[0]*Adc_V[0]*Adc_V[0]-633.9433*Adc_V[0]*Adc_V[0]+426.9017*Adc_V[0]-84.9469;   //XQ����������1ŷ��
				 //duty_now=0.0134*Adc_V[0]*Adc_V[0]*Adc_V[0]-0.0904*Adc_V[0]*Adc_V[0]+0.252*Adc_V[0]-0.032;
			    }
			else if(duty_flag==-1)
				{
				*Adcvalue=0.6777*(324.9*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]-2137.9*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]+5604.3*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]-7478.5*Adc_V[0]*Adc_V[0]*Adc_V[0]+5384.7*Adc_V[0]*Adc_V[0]-2083.7*Adc_V[0]+284.2);   //XQ����������3.3ŷ��(FIR��ͨ�˲�125HZ)
//				*Adcvalue=9.9*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]-110.7*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]+491*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]-1098.9*Adc_V[0]*Adc_V[0]*Adc_V[0]+1310.7*Adc_V[0]*Adc_V[0]-840.3*Adc_V[0]+173.7;   //XQ����������3.3ŷ��(�����С��ֵ�˲�)
//				  *Adcvalue=3.8298*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]-44.9705*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]+209.4831*Adc_V[0]*Adc_V[0]*Adc_V[0]*Adc_V[0]-492.9819*Adc_V[0]*Adc_V[0]*Adc_V[0]+619.9149*Adc_V[0]*Adc_V[0]-427.3167*Adc_V[0]+85.9631		//XQ����������1ŷ��																																;   //XQ
				 //duty_now=-0.0088*Adc_V[0]*Adc_V[0]*Adc_V[0]+0.070*Adc_V[0]*Adc_V[0]-0.232*Adc_V[0]+0.028;
			    }   
//       *(Adcvalue+1) =-8.754+32.787*Adc_V[1]; //TS
					
					*(Adcvalue+1) =-(1.5276-Adc_V[1])*100/1.2604+33; //TS
				
//					*(Adcvalue+1) =-(1.5276-Adc_V[1])*100; //TS
					
       *(Adcvalue+2) = -24.94+39.468*Adc_V[2]; //P
//	        if(AI1type==V10D||V10D_1)     *(Adcvalue+5) = 182.659-85.215*Adc_V[5];   //V �������С��ֵ�˲���  115.044-65.336*Adc_V[5]�Ϻ������ֱ��
			if(AI1type==V10D||V10D_1)     *(Adcvalue+5) = 180.207-115.74*Adc_V[5];   //V ��FIR��ͨ�˲�125HZ��115.044-65.336*Adc_V[5]�Ϻ������ֱ��
       else if(AI1type==V10S)             *(Adcvalue+5) = 107.522-32.668*Adc_V[5];   //V
	        if(AI2type==mA20D||mA20D_1)   *(Adcvalue+3) = 117.370-66.777*Adc_V[3];   //I
	   else if(AI2type==mA20S)            *(Adcvalue+3) = 108.685-33.388*Adc_V[3];	//I
       else if(AI2type==mA10D||mA10D_1)   *(Adcvalue+3) = 234.740-133.554*Adc_V[3];  //I
	   else if(AI2type==mA10S)            *(Adcvalue+3) = 167.370-66.776*Adc_V[3];	//I
	
//		    if(AI3type==V10D||V10D_1)     *(Adcvalue+6) = 179.814-85.055*Adc_V[6];   //FV �������С��ֵ�˲��� 114.303-64.981*Adc_V[6];�Ϻ������ֱ��
			if(AI3type==V10D||V10D_1)     *(Adcvalue+6) = 181.665-119.047*Adc_V[6];   //FV ��FIR��ͨ�˲�125HZ�� 114.303-64.981*Adc_V[6];�Ϻ������ֱ��
	   else if(AI3type==V10S)             *(Adcvalue+6) = 107.152-32.492*Adc_V[6];   //FV
	     	if(AI4type==mA20D||mA20D_1)   *(Adcvalue+4) = 116.945-66.862*Adc_V[4];   //FI
	   else if(AI4type==mA20S)            *(Adcvalue+4) = 108.472-33.431*Adc_V[4];	//FI
       else if(AI4type==mA10D||mA10D_1)   *(Adcvalue+4) = 233.890-133.724*Adc_V[4];  //FI
	   else if(AI4type==mA10S)            *(Adcvalue+4) = 166.944-66.862*Adc_V[4];	//FI			     
	  *(Adcvalue+7)= -25.099+39.533*Adc_V[7];	//T			
}

