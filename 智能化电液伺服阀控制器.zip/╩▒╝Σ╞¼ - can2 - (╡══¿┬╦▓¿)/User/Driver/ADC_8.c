
#include "main.h"
extern u8 Flag_20us;
u8 Flag_Pid=0;
volatile unsigned short m_ADCValue[ADC_SAMPLE_PNUM][ADC_SAMPLE_CNUM] = {0};
float32_t output_scan[ADC_SAMPLE_PNUM]={0.0};

#define BLOCK_SIZE 5 /* ����һ��arm_fir_f32�����Ĳ�������� */
#define NUM_TAPS 29 /* �˲���ϵ������ */
uint32_t blockSize = BLOCK_SIZE;
uint32_t numBlocks = ADC_SAMPLE_PNUM/BLOCK_SIZE; /* ��Ҫ����arm_fir_f32�Ĵ��� */
 float32_t testInput_f32_50Hz_200Hz[ADC_SAMPLE_PNUM]; /* ������ */
static float32_t testOutput[ADC_SAMPLE_PNUM]; /* �˲������� */
static float32_t firStateF32[BLOCK_SIZE + NUM_TAPS - 1]; /* ״̬���棬��СnumTaps + blockSize - 1*/

/* ��ͨ�˲���ϵ�� ͨ��fadtool��ȡ*/
const float32_t firCoeffs32LP[NUM_TAPS] = {
 -0.001822523074f, -0.001587929321f, 1.226008847e-18f, 0.003697750857f, 0.008075430058f,
 0.008530221879f, -4.273456581e-18f, -0.01739769801f, -0.03414586186f, -0.03335915506f,
 8.073562366e-18f, 0.06763084233f, 0.1522061825f, 0.2229246944f, 0.2504960895f,
0.2229246944f, 0.1522061825f, 0.06763084233f, 8.073562366e-18f, -0.03335915506f,
 -0.03414586186f, -0.01739769801f, -4.273456581e-18f, 0.008530221879f, 0.008075430058f,
 0.003697750857f, 1.226008847e-18f, -0.001587929321f, -0.001822523074f
};

void GPIO_ADC_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOC|RCC_AHB1Periph_DMA2,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
}
void ADC_Config_Conver(void)
{
	DMA_InitTypeDef    	  DMA_InitStructure;
	ADC_InitTypeDef       ADC_InitStructure;
	ADC_CommonInitTypeDef ADC_CommonInitStructure;
	
	DMA_Cmd(DMA2_Stream0, DISABLE); 
	DMA_InitStructure.DMA_Channel = DMA_Channel_0;  
	DMA_InitStructure.DMA_PeripheralBaseAddr = (unsigned int)&(ADC1->DR);
	DMA_InitStructure.DMA_Memory0BaseAddr = (unsigned int)&m_ADCValue;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
	DMA_InitStructure.DMA_BufferSize = ADC_SAMPLE_PNUM*ADC_SAMPLE_CNUM;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;  //ѭ��ģʽ
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;  
	DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable;
	DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
	DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
	DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
	DMA_Init(DMA2_Stream0, &DMA_InitStructure);

    ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;   //����ģʽ
	ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div2;//Ԥ��Ƶ4��Ƶ��ADCCLK=PCLK2/4=84/4=21Mhz,ADCʱ����ò�Ҫ����36Mhz
	ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled; //DMAʧ��
	ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;//���������׶�֮����ӳ�12��ʱ��
	ADC_CommonInit(&ADC_CommonInitStructure);

	ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;   //12λģʽ
	ADC_InitStructure.ADC_ScanConvMode = ENABLE;            //��ɨ��ģʽ
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;     //����ת��ģʽ
	ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None; //��������ģʽ
	ADC_InitStructure.ADC_ExternalTrigConv = 0;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_NbrOfConversion = ADC_SAMPLE_CNUM;
	ADC_Init(ADC1, &ADC_InitStructure);
    ADC_DMARequestAfterLastTransferCmd(ADC1, ENABLE);
	ADC_DMACmd(ADC1, ENABLE);
	ADC_Cmd(ADC1, ENABLE);
	DMA_Cmd(DMA2_Stream0, ENABLE);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_3Cycles);  //��Ȧ�����ɼ�   0
	ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 2, ADC_SampleTime_3Cycles);  //��оλ���źŲɼ� 1
	ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 3, ADC_SampleTime_3Cycles);  //ѹ���������ź�    2
	ADC_RegularChannelConfig(ADC1, ADC_Channel_3, 4, ADC_SampleTime_3Cycles);  //ѹ�����������ź�   3 
	ADC_RegularChannelConfig(ADC1, ADC_Channel_7, 5, ADC_SampleTime_3Cycles);  //�������������ź�  4 
	ADC_RegularChannelConfig(ADC1, ADC_Channel_8, 6, ADC_SampleTime_3Cycles);  //ѹ��������ѹ�ź�  5
	ADC_RegularChannelConfig(ADC1, ADC_Channel_9, 7, ADC_SampleTime_3Cycles);  //����������ѹ�ź�  6
	ADC_RegularChannelConfig(ADC1, ADC_Channel_11,8, ADC_SampleTime_3Cycles);  //�¶ȴ������ɼ�    7
	ADC_SoftwareStartConv(ADC1); //��������ģʽ����
}

// u16 ADC_Proc_Value(unsigned char nIndex)
//{
//		
//		u32 nValue = 0;
//		u32 nSum = 0;
//		u8 i = 0, j = 0,y = 0;
//		static u8 x = 0;
//		u16 Temp = 0;
//		arm_fir_instance_f32 S;
//		float32_t *inputF32, *outputF32;
//	
//		/* ��ʼ�������������ָ�� */
//		inputF32 = &testInput_f32_50Hz_200Hz[0];
//		outputF32 = &testOutput[0];
//	
//	
//		/* ��ʼ���ṹ��S */
//		arm_fir_init_f32(&S,NUM_TAPS,(float32_t *)&firCoeffs32LP[0],&firStateF32[0],blockSize);
//	
//		/* ʵ��FIR�˲�������ÿ�δ���1���� */
//		for(i=0; i < numBlocks; i++)
//		{
//		   arm_fir_f32(&S, inputF32 + (i * blockSize), outputF32 + (i * blockSize), blockSize);
//		}
//		
//}

u16  ADC_Proc_Value(unsigned char nIndex)
{ 	
  u32 nValue = 0;
	u32 nSum = 0;
	u8 i = 0, j = 0,y = 0;
	static u8 x = 0;
	u16 Temp = 0;	
	u16 tempArray[ADC_SAMPLE_PNUM] = {0};
	static u16 temp_huadong[50][50]={0};
	arm_fir_instance_f32 S;
	float32_t *inputF32, *outputF32;
	
    nValue = 0;
	
	/* ��ʼ�������������ָ�� */
	inputF32 = &testInput_f32_50Hz_200Hz[0];
	outputF32 = &testOutput[0];
	arm_fir_init_f32(&S,NUM_TAPS,(float32_t *)&firCoeffs32LP[0],&firStateF32[0],blockSize);/* ��ʼ���ṹ��S */
	for(i=0; i<ADC_SAMPLE_PNUM; i++)			 //�ɼ���ʮ��		
	{	
		testInput_f32_50Hz_200Hz[i]= (float)m_ADCValue[i][nIndex];				
	}
	inputF32 = &testInput_f32_50Hz_200Hz[0];
	for(i=0; i < numBlocks; i++)
	{
		arm_fir_f32(&S, inputF32+(i * blockSize) , outputF32+(i * blockSize) , blockSize);
	}
	for(i=0; i<ADC_SAMPLE_PNUM; i++)
	{
		output_scan[i]=testOutput[i];
		nSum+=output_scan[i];
	}
	nValue=nSum/ADC_SAMPLE_PNUM;
	
	
	
	
	
//	for(i=0; i<ADC_SAMPLE_PNUM; i++)			 //�ɼ���ʮ��		
//	{		
//		tempArray[i] = m_ADCValue[i][nIndex];
//	}
//	for(i=0; i<ADC_SAMPLE_PNUM-1; i++)	   //ȥ�����ֵ				
//	{
//		for(j = i+1; j< ADC_SAMPLE_PNUM ;j++)
//		{
//			if(tempArray[j] < tempArray[i])
//			{
//				Temp = tempArray[i];
//				tempArray[i] = tempArray[j];
//				tempArray[j] = Temp;
//			}
//		}
//	}	
//	for(i=10; i<ADC_SAMPLE_PNUM-10; i++)					
//	{
//		nSum += tempArray[i] ;
//	}
//	
//	
//	
//	nValue = nSum / (ADC_SAMPLE_PNUM-20);               //��ͷȥβ���ֵ
////	
	
	
//	 temp_huadong[x][nIndex] = nSum / (ADC_SAMPLE_PNUM-20);               //��ͷȥβ���ֵ
//	 x++;
//	 if(x==ADC_SAMPLE_HUADONG)                                    //�������ͷ�滻ֵ
//		 x=0;
//	 for(y=0;y<ADC_SAMPLE_HUADONG;y++)                            //�󻬶������ֵ
//		 nValue+=temp_huadong[y][nIndex];
//	 nValue=nValue/ADC_SAMPLE_HUADONG;
	 
	 
	 return nValue;                                               //�����ֵ
	 

}



union Transfer
{

	float   Float_data;//stm32��float4���ֽ�ռ32λ
	uint8_t Byte[4];   //4��uint8_t����Ԫ��ռ8λ
}transunion,*transptr=&transunion;

uint32_t Float_To_Int(float data)
{
uint32_t Flash_uInt=0;
transptr->Byte[0]=((uint8_t *)&data)[0]; 
transptr->Byte[1]=((uint8_t *)&data)[1];
transptr->Byte[2]=((uint8_t *)&data)[2];
transptr->Byte[3]=((uint8_t *)&data)[3];
Flash_uInt=*(uint32_t*)transptr->Byte;
return Flash_uInt;
}
 
float Int_To_Float(uint32_t data)
{
double Flash_flt=0.0;
transptr->Byte[0]=data&0xff;
transptr->Byte[1]=(data>>8)&0xff;
transptr->Byte[2]=(data>>16)&0xff;
transptr->Byte[3]=(data>>24)&0xff;
Flash_flt=transptr->Float_data;//
return Flash_flt;
}


