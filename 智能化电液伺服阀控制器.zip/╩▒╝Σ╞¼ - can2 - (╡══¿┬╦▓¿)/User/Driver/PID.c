#include "main.h" 
#include "config.h"
float  I_error=0.0;
extern arm_pid_instance_f32  P_loop_PID;//PID��λ������  
extern arm_pid_instance_f32  I_loop_PID;
extern arm_pid_instance_f32  Q_loop_PID;
float Current_PID(float Current_Target,float Current_now)//�����ջ�PID����,����ռ�ձȣ�50%���Ϊ0
{  
	float duty_t=0.0;
        I_error=(Current_Target-Current_now);
     	duty_t = (arm_pid_f32(&I_loop_PID, I_error))/100.0;	
    if(duty_t>=0.30)  duty_t=0.30;
    else  if(duty_t<=-0.38)duty_t=-0.38;
	return duty_t;
}

float Q_error=0;
float Flow_PID(float Target,float flow_now)//�����ջ�PID���㣬����ֵΪ�����趨ֵ Current_Target
{

        
    float duty_t=0.0;
    Q_error	=Target-flow_now;

    duty_t = (arm_pid_f32(&Q_loop_PID, Q_error))/100.0;
	 if(duty_t>=0.04) 
		 duty_t=0.04;
    else  if(duty_t<=-0.04)
			duty_t=-0.04;
//	if(duty_t>=1450)
//		 duty_t=1450;
//	if(duty_t<=550)
//		 duty_t=550.0;
	  return duty_t;
}

float P_error=0;
float Pressure_PID(float Target,float P_now)//ѹ���ջ�PID����
{     
			float duty_t=0;
		 P_error	=Target-P_now;
		duty_t = (arm_pid_f32(&P_loop_PID, P_error))/100.0;
//	if(duty_t>=0.30)  duty_t=0.30;
//    else  if(duty_t<=-0.38)duty_t=-0.38;
			return duty_t;
}

