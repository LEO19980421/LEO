#ifndef __HARDWARE_H
#define	__HARDWARE_H

#include "stm32f4xx.h"

//LED�����Ŷ���
/*******************************************************/

#define LED1_PIN                  GPIO_Pin_14                 
#define LED1_GPIO_PORT            GPIOC                      
#define LED1_GPIO_CLK             RCC_AHB1Periph_GPIOC


#define LED2_PIN                  GPIO_Pin_1                 
#define LED2_GPIO_PORT            GPIOE                    
#define LED2_GPIO_CLK             RCC_AHB1Periph_GPIOE


#define LED3_PIN                  GPIO_Pin_9                
#define LED3_GPIO_PORT            GPIOB                       
#define LED3_GPIO_CLK             RCC_AHB1Periph_GPIOB

#define LED4_PIN                  GPIO_Pin_0                
#define LED4_GPIO_PORT            GPIOE                       
#define LED4_GPIO_CLK             RCC_AHB1Periph_GPIOE

//��ɫ�����Ŷ���
#define Blue1_PIN                  GPIO_Pin_2                
#define Blue1_GPIO_PORT            GPIOE                     
#define Blue1_GPIO_CLK             RCC_AHB1Periph_GPIOE


#define Green1_PIN                  GPIO_Pin_3               
#define Green1_GPIO_PORT            GPIOE                      
#define Green1_GPIO_CLK             RCC_AHB1Periph_GPIOE

#define Red1_PIN                  GPIO_Pin_4               
#define Red1_GPIO_PORT            GPIOE                      
#define Red1_GPIO_CLK             RCC_AHB1Periph_GPIOE

#define Blue2_PIN                  GPIO_Pin_5                 
#define Blue2_GPIO_PORT            GPIOE                      
#define Blue2_GPIO_CLK             RCC_AHB1Periph_GPIOE

#define Green2_PIN                  GPIO_Pin_6               
#define Green2_GPIO_PORT            GPIOE                      
#define Green2_GPIO_CLK             RCC_AHB1Periph_GPIOE

#define Red2_PIN                  GPIO_Pin_13               
#define Red2_GPIO_PORT            GPIOC                      
#define Red2_GPIO_CLK             RCC_AHB1Periph_GPIOC

//ʹ���ź����Ŷ���
#define Power24_PIN                  GPIO_Pin_14                
#define Power24_GPIO_PORT            GPIOB                      
#define Power24_GPIO_CLK             RCC_AHB1Periph_GPIOB
#define Power24_ENABLE 		         GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14) 

//�����źż�����Ŷ���
#define ERROR_PIN                    GPIO_Pin_8                
#define ERROR_GPIO_PORT              GPIOA                      
#define ERROR_GPIO_CLK               RCC_AHB1Periph_GPIOA





/************************************************************/


/** ����LED������ĺ꣬
	* LED�͵�ƽ��������ON=0��OFF=1
	* ��LED�ߵ�ƽ�����Ѻ����ó�ON=1 ��OFF=0 ����
	*/
#define ON  0
#define OFF 1

/* ���κ꣬��������������һ��ʹ�� */
#define LED1(a)	if (a)	\
					GPIO_SetBits(LED1_GPIO_PORT,LED1_PIN);\
					else		\
					GPIO_ResetBits(LED1_GPIO_PORT,LED1_PIN)

#define LED2(a)	if (a)	\
					GPIO_SetBits(LED2_GPIO_PORT,LED2_PIN);\
					else		\
					GPIO_ResetBits(LED2_GPIO_PORT,LED2_PIN)

#define LED3(a)	if (a)	\
					GPIO_SetBits(LED3_GPIO_PORT,LED3_PIN);\
					else		\
					GPIO_ResetBits(LED3_GPIO_PORT,LED3_PIN)
#define LED4(a)	if (a)	\
					GPIO_SetBits(LED4_GPIO_PORT,LED4_PIN);\
					else		\
					GPIO_ResetBits(LED4_GPIO_PORT,LED4_PIN)

#define Blue1(a)	if (a)	\
					GPIO_SetBits(Blue1_GPIO_PORT,Blue1_PIN);\
					else		\
					GPIO_ResetBits(Blue1_GPIO_PORT,Blue1_PIN)

#define Blue2(a)	if (a)	\
					GPIO_SetBits(Blue2_GPIO_PORT,Blue2_PIN);\
					else		\
					GPIO_ResetBits(Blue2_GPIO_PORT,Blue2_PIN)

#define Green1(a)	if (a)	\
					GPIO_SetBits(Green1_GPIO_PORT,Green1_PIN);\
					else		\
					GPIO_ResetBits(Green1_GPIO_PORT,Green1_PIN)

#define Green2(a)	if (a)	\
					GPIO_SetBits(Green2_GPIO_PORT,Green2_PIN);\
					else		\
					GPIO_ResetBits(Green2_GPIO_PORT,Green2_PIN)

#define Red1(a)	if (a)	\
					GPIO_SetBits(Red1_GPIO_PORT,Red1_PIN);\
					else		\
					GPIO_ResetBits(Red1_GPIO_PORT,Red1_PIN)

#define Red2(a)	if (a)	\
					GPIO_SetBits(Red2_GPIO_PORT,Red2_PIN);\
					else		\
					GPIO_ResetBits(Red2_GPIO_PORT,Red2_PIN)

#define ERROR_CHECK(a)	if (a)	\
					    GPIO_SetBits(ERROR_GPIO_PORT,ERROR_PIN);\
					    else		\
					    GPIO_ResetBits(ERROR_GPIO_PORT,ERROR_PIN)
						
						 


#define LED1Toggle GPIO_ToggleBits(LED1_GPIO_PORT,LED1_PIN);
#define LED2Toggle GPIO_ToggleBits(LED2_GPIO_PORT,LED2_PIN);
#define LED3Toggle GPIO_ToggleBits(LED3_GPIO_PORT,LED3_PIN);
#define LED4Toggle GPIO_ToggleBits(LED4_GPIO_PORT,LED4_PIN);
#define Red1Toggle GPIO_ToggleBits(Red1_GPIO_PORT,Red1_PIN);
#define Red2Toggle GPIO_ToggleBits(Red2_GPIO_PORT,Red2_PIN);
#define Green1Toggle GPIO_ToggleBits(Green1_GPIO_PORT,Green1_PIN);
#define Green2Toggle GPIO_ToggleBits(Green2_GPIO_PORT,Green2_PIN);
#define Blue1Toggle GPIO_ToggleBits(Blue1_GPIO_PORT,Blue1_PIN);
#define Blue2Toggle GPIO_ToggleBits(Blue2_GPIO_PORT,Blue2_PIN);
			
void LED_GPIO_Config(void);
void Color3_LED_GPIO_Config(void);
void NVIC_Configuration(void);
void VIN24_Init(void);
void ERROR_OUT(void);
void IWDG_Init(u8 prer,u16 rlc);
void IWDG_Feed(void);
#endif /* __HARDWARE_H */


