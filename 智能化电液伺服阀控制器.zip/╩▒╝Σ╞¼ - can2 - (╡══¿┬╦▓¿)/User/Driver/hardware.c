/**
  ******************************************************************************
  * @file    bsp_led.c
  * @author  fire
  * @version V1.0
  * @date    2015-xx-xx
  * @brief   Ӳ��������
  ******************************************************************************
  * @attention

  ******************************************************************************
  */
#include "main.h"
    /**
  * @brief  ��ʼ������LED��IO
  * @param  ��
  * @retval ��
  */
void LED_GPIO_Config(void)
{		
			
		GPIO_InitTypeDef GPIO_InitStructure;
		RCC_AHB1PeriphClockCmd (LED1_GPIO_CLK|LED2_GPIO_CLK|LED3_GPIO_CLK|LED4_GPIO_CLK, ENABLE); 															   
		GPIO_InitStructure.GPIO_Pin = LED1_PIN;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
        GPIO_Init(LED1_GPIO_PORT, &GPIO_InitStructure);	
	
	    GPIO_InitStructure.GPIO_Pin = LED2_PIN;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
        GPIO_Init(LED2_GPIO_PORT, &GPIO_InitStructure);
	
	    GPIO_InitStructure.GPIO_Pin = LED3_PIN;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
        GPIO_Init(LED3_GPIO_PORT, &GPIO_InitStructure);
		
		GPIO_InitStructure.GPIO_Pin = LED4_PIN;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
        GPIO_Init(LED4_GPIO_PORT, &GPIO_InitStructure);
	
//	    GPIO_SetBits(LED1_GPIO_PORT,LED1_PIN);
//	    GPIO_SetBits(LED2_GPIO_PORT,LED2_PIN);
//	    GPIO_SetBits(LED3_GPIO_PORT,LED3_PIN);
//	    GPIO_SetBits(LED4_GPIO_PORT,LED4_PIN);
	 
    
}

void Color3_LED_GPIO_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
    RCC_AHB1PeriphClockCmd (Red1_GPIO_CLK|Red2_GPIO_CLK|Green1_GPIO_CLK|Green2_GPIO_CLK|Blue1_GPIO_CLK|Blue2_GPIO_CLK, ENABLE); 
	
    GPIO_InitStructure.GPIO_Pin = Blue1_PIN|Blue2_PIN|Green1_PIN|Green2_PIN|Red1_PIN|Red2_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;       
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;    
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	
    GPIO_Init(Blue1_GPIO_PORT, &GPIO_InitStructure);	
    GPIO_Init(Blue2_GPIO_PORT, &GPIO_InitStructure);	
    GPIO_Init(Green1_GPIO_PORT, &GPIO_InitStructure);		
    GPIO_Init(Green2_GPIO_PORT, &GPIO_InitStructure);
    GPIO_Init(Red1_GPIO_PORT, &GPIO_InitStructure);		
    GPIO_Init(Red2_GPIO_PORT, &GPIO_InitStructure);
}

void NVIC_Configuration(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;   //TIM2 
//    NVIC_InitStructure.NVIC_IRQChannel = TIM7_IRQn; 	
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;	 
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 5;	
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//    NVIC_Init(&NVIC_InitStructure);

  	NVIC_InitStructure.NVIC_IRQChannel = CAN1_RX0_IRQn;        //can1
//NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;     // �����ȼ�Ϊ1
//NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;            // �����ȼ�Ϊ0
  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  	NVIC_Init(&NVIC_InitStructure);
	
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 
//	NVIC_SetVectorTable(NVIC_VectTab_FLASH, VectTab_ADDRESS);          //flash
//	NVIC_Init(&NVIC_InitStructure);
//	__set_PRIMASK(0);//�������ж�
//	__enable_irq() ; //�����ж�
	
	NVIC_InitStructure.NVIC_IRQChannel=TIM3_IRQn; //��ʱ��3�ж�
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0x01; //��ռ���ȼ�1
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0x00; //�����ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}
 
void VIN24_Init(void)
{
	
  GPIO_InitTypeDef  GPIO_InitStructure;
  RCC_AHB1PeriphClockCmd(Power24_GPIO_CLK, ENABLE);//ʹ��GPIOA,GPIOEʱ�� 
  GPIO_InitStructure.GPIO_Pin = Power24_PIN; //KEY0 KEY1 KEY2��Ӧ����
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//��ͨ����ģʽ
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100M
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
  GPIO_Init(Power24_GPIO_PORT, &GPIO_InitStructure);//��ʼ��GPIOE2,3,4
} 


void ERROR_OUT(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
  RCC_AHB1PeriphClockCmd(ERROR_GPIO_CLK, ENABLE);//ʹ��GPIOA,GPIOEʱ�� 
  GPIO_InitStructure.GPIO_Pin = ERROR_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz; 
  GPIO_Init(ERROR_GPIO_PORT, &GPIO_InitStructure);	
} 
void IWDG_Init(u8 prer,u16 rlr)  //Tout=((4��2^prer) ��rlr) /40
{  
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable); 
	IWDG_SetPrescaler(prer); 
	IWDG_SetReload(rlr);   
	IWDG_ReloadCounter(); 
	IWDG_Enable();       
}
void IWDG_Feed(void)
{
	IWDG_ReloadCounter();
}




/*********************************************END OF FILE**********************/



