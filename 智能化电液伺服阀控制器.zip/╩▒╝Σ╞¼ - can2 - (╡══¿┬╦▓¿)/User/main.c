/**
  ******************************************************************************
  * @file    main.C_PrepareSeting
  * @author  DXQ
  * @version V1.0
  * @date    2021-08-16
  * @brief   �����ŷ���������
  ******************************************************************************
  * @attention
  *

  ******************************************************************************
  */
#include "main.h"
/**
  * @brief  ������
  * @param  ��
  * @retval ��
  */      
  


//////���ջ�pid���ߵ���
arm_pid_instance_f32  P_loop_PID;  
arm_pid_instance_f32  I_loop_PID;
arm_pid_instance_f32  Q_loop_PID;

//float LIULIANGPID=0.0;
extern int Runmode,DAC_ONOFF;//����ģʽ
int  Feedback_buf[8]={0};//����״̬����
uint8_t AI1type=1,AI2type=1,AI3type=1,AI4type=1;//ģ�����������ͣ�����ģ�����������Ͷ���
u8 Pid_flow_pressure_flag=0;//˫�ջ���־λ
float Flow_setting=0;       //ѹ���ջ������趨ֵ
float duty = 0.0,Q_duty = 0.0,P_duty = 0.0;
float C_PrepareSeting=0.0; 
float Out_I,Out_V,Out_Scale,Out_gain,Out_deadzoom,Out_zero,P_fuhao,Out_Q1,Out_P1,ZERO_COrrect1=0.0;//�źŵ����������ֵ
extern uint16_t Trunled;
int duty_flag=1;    //�ж�duty������
float duty_now=0;   //ʵ����Ȧ������Ӧ��ռ�ձ�
extern uint16_t T_can1send,T_can2send;
extern uint64_t T_Analog_input,T_Constant_input,T_Other_status,T_Analog_input_1;

extern uint64_t Flag_500ms,Default_ms,Pre_ms,can1_bling;
extern float   I_Target,P_Target,Q_Target;//������ѹ����������������
extern 	int  Input_P_type,Input_Q_type,Input_type,Output_type_P,Output_type_Q; //�����������루ѹ��������
extern  int  P_Factor_A1,  P_Factor_B1,  Q_Factor_A1,  Q_Factor_B1,   P_Offset1,Q_Offset1,
             P_Factor_A2,  P_Factor_B2,  Q_Factor_A2,  Q_Factor_B2,   P_Offset2,Q_Offset2,
             P_Factor_A3,  P_Factor_B3,  Q_Factor_A3,  Q_Factor_B3,   Q_Factor_A4,Q_Factor_B4,
             minzerovalue, maxzerovalue, Offset_zero,  Q_ZERO,P_ZERO, Q_Offset;  //�źŵ���ϵ��
extern int    Q_Limit_Min, Q_Limit_Max,  P_Limit_Max,P_Limit_Min;
extern float  P_close_loop_P,P_close_loop_I,P_close_loop_D,
	            Q_close_loop_P,Q_close_loop_I,Q_close_loop_D,
              I_close_loop_P,I_close_loop_I,I_close_loop_D; ////ѹ��������������������
extern float  I_default,Spool_default,Spool_zero_default;  //����ֵ�趨
extern int     sign_Positive;  //ѹ�������������趨
extern u8     ARR_pwm,PSC_pwm;
extern u8     Flag_PIDchange_Flow,Flag_PIDchange_Pre,Flag_PIDchange_Current,CPU_restart;  //��λ������PID������־λ
extern u8     PWM_FLAG;
float AD_init_test=0.0;      //AD��ʼ���� �жϵ�һ�β���ֵ�Ƿ���ȷ
u8 Init_error_flag=0;
u8 Read_Data[16]={0};
u8 tt1=0,AD_errorflag=0,Powerstatus=0;  //AD���ϼ��
int CAN1_float_values=0,CAN1_RT_ERROR=0;   //can�շ������־
u16  ii1=0,ii2=0,ii3=0;
float ADC_Value_8[10]={0.0};   //�ٷ���
float A_duty=0.0;
float temp_T=0.0;
u8  worning=0;
u8 Power24_stat=0,Enable_stat=0,Power_enforce=0;
u32 can_send1[8]={0};
int arr_flag=0,psc_flag=0;



//u32 t1st=500000;
int main(void)
{
			SystemInit();
			delay_init(168);
//			TIMx_Configuration();			
	        TIM1_PWM_Init(Duty_Period,0);
			TIM3_Int_Init(50-1,168-1);	//�������100us 
		    Color3_LED_GPIO_Config();
		    LED_GPIO_Config();//led��������
	        VIN24_Init();
		    ERROR_OUT();        //       
			IIC_Init();
			Dac_Init();
			CAN1_Configuration(500);//CAN��ʼ�� 500kbps
	delay_ms(5);
	        GPIO_ADC_Config();
	      	delay_ms(500);
			ADC_Config_Conver();
			delay_ms(500);
		    NVIC_Configuration();
			IWDG_Init(IWDG_Prescaler_256,2500);  //���Ź�16s
//			Red1(0);Blue1(0);Green1(0);
//			Red2(0);Blue2(0);Green2(0);	
			Initilize_CAT24C32();
			PWM_Dutyset(0.2);	
			Get_Adcvalue(ADC_Value_8);
			Get_Adcvalue(ADC_Value_8);
			Get_Adcvalue(ADC_Value_8);
			if(ADC_Value_8[0]<=0)
			RestartCPU();
			ADC_Value_8[10]=0;
			PWM_Dutyset(0);	
			Factory_value_status();
			duty=0;
		    A_duty=0;
			
//while(1)
//{
//	PWM_Dutyset(0.00);
//	IWDG_Feed();
//	Get_Adcvalue(ADC_Value_8);
//	delay_ms(20);
//	
//}
			
while (1)
{
	PeachOSRun();	
}

}



//������Ƭ��
void RestartCPU(void)
{
			////������������//////
			__set_FAULTMASK(1); //�ر������ж�
			NVIC_SystemReset(); //��λ
			//////////////////////////////////
}


void PID_change(void)
{
	 if(Flag_PIDchange_Flow==1) //�����ջ�PID��ʼ��
			 {
					 Q_loop_PID.Kp=Q_close_loop_P;
					 Q_loop_PID.Ki=Q_close_loop_I;
					 Q_loop_PID.Kd=Q_close_loop_D;
//					 arm_pid_reset_f32(&Q_loop_PID);
					 arm_pid_init_f32(&Q_loop_PID, 0);
					 Flag_PIDchange_Flow=0;
			 }
			 if(Flag_PIDchange_Current==1) //�����ջ�PID��ʼ��
			 {
					 I_loop_PID.Kp=I_close_loop_P;
					 I_loop_PID.Ki=I_close_loop_I;
					 I_loop_PID.Kd=I_close_loop_D;
//					 arm_pid_reset_f32(&I_loop_PID);
					 arm_pid_init_f32(&I_loop_PID, 0);
					 Flag_PIDchange_Current=0;
			 }
			 if(Flag_PIDchange_Pre==1)    //ѹ���ջ�PID��ʼ��
			 {
					 P_loop_PID.Kp=P_close_loop_P;
					 P_loop_PID.Ki=P_close_loop_I;
					 P_loop_PID.Kd=P_close_loop_D;
//					 arm_pid_reset_f32(&P_loop_PID);
					 arm_pid_init_f32(&P_loop_PID, 0);
					 Flag_PIDchange_Pre=0;
			 }
}
void Factory_value_status(void)
{    
	float duty1=0.0; 
	 float ADC_ii3[8]={0.0},duty_t=0.1;
	   u8  lingweipiaoyi=0;		
	  u8    kazhi_status=0; 
	if(Init_error_flag==1)
	{	
	
		Get_Adcvalue(ADC_Value_8);
		if(ADC_Value_8[0]>=-100&ADC_Value_8[0]<=100)    //��Ȧ��������
		 {  
				   Blue1(0);Red1(0);
				   Green1(1);delay_ms(200);Green1(0);delay_ms(200);	IWDG_Feed();
				   Green1(1);delay_ms(200);Green1(0);delay_ms(200);	IWDG_Feed();
				   Green1(1);delay_ms(200);Green1(0);delay_ms(200);	IWDG_Feed();
				   AD_errorflag=0;Green1(1);Powerstatus=0;     // ϵͳ�ϵ��⣬AD��������������ϵͳ�Ѿ��ϵ�
				   delay_ms(200);
		 }
		 else
		 {          Green1(0);
					Blue1(1);Red1(1);delay_ms(200);Red1(0);Blue1(0);delay_ms(200);	IWDG_Feed();
					Blue1(1);Red1(1);delay_ms(200);Red1(0);Blue1(0);delay_ms(200);	IWDG_Feed();
					Blue1(1);Red1(1);delay_ms(200);Red1(0);Blue1(0);delay_ms(200);	IWDG_Feed();
					AD_errorflag=1;Blue1(1);Red1(1);Powerstatus=1; 
		 }
					Init_error_flag=2; 
				    if(Power24_ENABLE==Power24_stat) //���ⲿ24Vʹ���źŽ��룬��ʹ���ⲿʹ���źſ���
					   Enable_stat=1;
				    else
					   Enable_stat=0;
    }
			 
	 if(Init_error_flag==2)      // ����Ȧ�����쳣��  ����Ϊ�̵���˸���Σ����� ��ɫ
	 {

				if(Powerstatus==0)    
			{	
				 if(fabs(ADC_Value_8[0])>I_default)        // ����Ȧ�����쳣    50mA     10%
				 { 
				     Red1(0); Green1(1);Blue1(1);delay_ms(200);						IWDG_Feed();//���Ź�
					 Green1(0);Blue1(0);delay_ms(200);						IWDG_Feed();
					 Green1(1);Blue1(1);delay_ms(200);						IWDG_Feed();
					 Green1(0);Blue1(0);delay_ms(200);						IWDG_Feed();
					 Green1(1);Blue1(1);delay_ms(200);						IWDG_Feed();
					 Green1(0);Blue1(0);delay_ms(200);						IWDG_Feed();
					 Green1(1);Blue1(1);C_PrepareSeting=1;Init_error_flag=3;
				 }  
			   else 
				 {
					 Green1(1);delay_ms(200); Green1(0);delay_ms(200);IWDG_Feed();
					 Green1(1);delay_ms(200); Green1(0);delay_ms(200);IWDG_Feed();
					 Green1(1);delay_ms(200); Green1(0);delay_ms(200);IWDG_Feed();
					 Green1(1);C_PrepareSeting=0;Init_error_flag=3;
				 }
					 delay_ms(200);delay_ms(200);IWDG_Feed();
				     delay_ms(200);delay_ms(200);						IWDG_Feed();
					 Green1(0);Blue1(0);Red1(0);
					 Feedback_buf[0]=35;             //35  ��Ȧ��·״̬ AD POWER_Status
					 Feedback_buf[1]=C_PrepareSeting;
					 Feedback_buf[2]=AD_errorflag;
					 Feedback_buf[3]=Powerstatus;
					 CAN1_Send_Msg(CANID_stats,Feedback_buf,8);
			}
	 }
	 /////////////////////////////////////////////////   ����״̬���
	
	if(Init_error_flag==3) //��о��λƯ��   +�����ջ�   ����   ��ɫ
	{
		
		Get_Adcvalue(ADC_Value_8);	
		while(ii1<50)
		{					    	 
			 Get_Adcvalue(ADC_Value_8);	
			 duty1 = Current_PID(0,ADC_Value_8[0]);//�����ջ�PID����
             PWM_Dutyset(duty1);	
			 ii1++;
		}
									   ii1=0;		
           		
							 if(fabs(duty1)<=Spool_zero_default)         //        50  
							 {
									 Green1(1);delay_ms(200); Green1(0);delay_ms(200);						IWDG_Feed();
									 Green1(1);delay_ms(200); Green1(0);delay_ms(200);						IWDG_Feed();
									 Green1(1);delay_ms(200); Green1(0);delay_ms(200);						IWDG_Feed();
				           Green1(1);	
								   lingweipiaoyi=0;	
							 }
							 else
							 {
					 					 Red1(1); Green1(1);delay_ms(200);						IWDG_Feed();
								     Red1(0); Green1(0);delay_ms(200);						IWDG_Feed();
					 					 Red1(1); Green1(1);delay_ms(200);						IWDG_Feed();
								     Red1(0); Green1(0);delay_ms(200);						IWDG_Feed();
					 					 Red1(1); Green1(1);delay_ms(200);						IWDG_Feed();
								     Red1(0); Green1(0);delay_ms(200);						IWDG_Feed();
								     Red1(1); Green1(1);
								     lingweipiaoyi=1;	    								 
							 }
							 		delay_ms(200);delay_ms(200);						IWDG_Feed();
							    delay_ms(200);delay_ms(200);						IWDG_Feed();
					        Green1(0);Blue1(0);Red1(0);
									Feedback_buf[0]=36;             //34  LVDT״̬����
									Feedback_buf[1]=lingweipiaoyi;
									CAN1_Send_Msg(CANID_stats,Feedback_buf,8);
							 	  Init_error_flag=4; 
	}	
							
							
							 if(Init_error_flag==4) //��о����        �����ǰ�ɫ
							{										
								 PWM_Dutyset(duty_t);
							   delay_ms(100);										
					    	 Get_Adcvalue(ADC_Value_8);	
								 ADC_ii3[0]=ADC_Value_8[1];
								 PWM_Dutyset(-1*duty_t);
								 delay_ms(100);									
					    	 Get_Adcvalue(ADC_Value_8);	
								 ADC_ii3[1]=ADC_Value_8[1];			
							  if(fabs(ADC_ii3[1]-ADC_ii3[0])<=Spool_default)
										 {
										 Red1(1);Green1(1);Blue1(1);delay_ms(200);						IWDG_Feed();
										 Red1(0);Green1(0);Blue1(0);delay_ms(200);						IWDG_Feed();
										 Red1(1);Green1(1);Blue1(1);delay_ms(200);						IWDG_Feed();
										 Red1(0);Green1(0);Blue1(0);delay_ms(200);						IWDG_Feed();
										 Red1(1);Green1(1);Blue1(1);delay_ms(200);						IWDG_Feed();
										 Red1(0);Green1(0);Blue1(0);delay_ms(200);						IWDG_Feed();
                     Red1(1);Green1(1);Blue1(1);
										 kazhi_status=1;										 
										 }
										 else
										 {
										 Green1(1);delay_ms(200); 					IWDG_Feed();
										 Green1(0);delay_ms(200);						IWDG_Feed();
										 Green1(1);delay_ms(200); 					IWDG_Feed();
										 Green1(0);delay_ms(200);						IWDG_Feed();
										 Green1(1);delay_ms(200); 					IWDG_Feed();
										 Green1(0);delay_ms(200);						IWDG_Feed();
										 Green1(1);
										 kazhi_status=0;		
										 }
										delay_ms(250);delay_ms(250);						IWDG_Feed();
										delay_ms(250);delay_ms(250);						IWDG_Feed();
										Green1(0);Blue1(0);Red1(0);
										Feedback_buf[0]=34;             //34  ����״̬����
										Feedback_buf[1]=kazhi_status;        //
										CAN1_Send_Msg(CANID_stats,Feedback_buf,8);
										Init_error_flag=5;										 
							}	
						
    if(Power24_ENABLE==Power24_stat) //���ⲿ24Vʹ���źŽ��룬��ʹ���ⲿʹ���źſ���
		Enable_stat=1;
	else
	    Enable_stat=0;
	Feedback_buf[0]=33;              //33  �ⲿ��Դʹ���ж�
    Feedback_buf[1]=Enable_stat;
    CAN1_Send_Msg(CANID_stats,Feedback_buf,8);		
	Init_error_flag=6;										 
	
}
void Initilize_CAT24C32(void)
{
 if(Init_error_flag==0)
{
//�޷�����
				Read_Data[0]=ReadOneByte(MQ_Limit_Min11); 
				Read_Data[1]=ReadOneByte(MQ_Limit_Min12); 
				Read_Data[2]=ReadOneByte(MQ_Limit_Max11); 
				Read_Data[3]=ReadOneByte(MQ_Limit_Max12); 
				Q_Limit_Min=(Read_Data[0]<<8)+Read_Data[1];
				Q_Limit_Max=(Read_Data[2]<<8)+Read_Data[3];	

  //�����������ű�������
				Read_Data[0]=ReadOneByte(MQ_Factor_A21); 
				Read_Data[1]=ReadOneByte(MQ_Factor_A22); 
				Read_Data[2]=ReadOneByte(MQ_Factor_B21); 
				Read_Data[3]=ReadOneByte(MQ_Factor_B22); 
				Read_Data[4]=ReadOneByte(MQ_Offset21); 
				Read_Data[5]=ReadOneByte(MQ_Offset22); 
				Q_Factor_A2=(Read_Data[0]<<8)+Read_Data[1];
				Q_Factor_B2=(Read_Data[2]<<8)+Read_Data[3];
				Q_Offset2=(Read_Data[4]<<8)+Read_Data[5];
 //���߸���������

				Read_Data[0]=ReadOneByte(MQ_Factor_A31); 
				Read_Data[1]=ReadOneByte(MQ_Factor_A32); 
				Read_Data[2]=ReadOneByte(MQ_Factor_B31); 
				Read_Data[3]=ReadOneByte(MQ_Factor_B32); 
				Q_Factor_A3=(Read_Data[0]<<8)+Read_Data[1];
				Q_Factor_B3=(Read_Data[2]<<8)+Read_Data[3];					 
 //��������������
							 
				Read_Data[0]=ReadOneByte(MQ_Factor_A41); 
				Read_Data[1]=ReadOneByte(MQ_Factor_A42); 
				Read_Data[2]=ReadOneByte(MQ_Factor_B41); 
				Read_Data[3]=ReadOneByte(MQ_Factor_B42); 
				Q_Factor_A4=(Read_Data[0]<<8)+Read_Data[1];
				Q_Factor_B4=(Read_Data[2]<<8)+Read_Data[3];
 //����������������
							 
				Read_Data[0]=ReadOneByte(Mminzerovalue11); 
				Read_Data[1]=ReadOneByte(Mminzerovalue12); 
				Read_Data[2]=ReadOneByte(Mmaxzerovalue11); 
				Read_Data[3]=ReadOneByte(Mmaxzerovalue12); 
				minzerovalue=(Read_Data[0]<<8)+Read_Data[1];
				maxzerovalue=(Read_Data[2]<<8)+Read_Data[3];
//��λ��������	
				Read_Data[0]=ReadOneByte(MOffset_zero11); 
				Read_Data[1]=ReadOneByte(MOffset_zero12); 					
				Offset_zero=(Read_Data[0]<<8)+Read_Data[1];			
 //ѹ�������޷�����
			
				Read_Data[0]=ReadOneByte(MP_Limit_Min11); 
				Read_Data[1]=ReadOneByte(MP_Limit_Min12); 
				Read_Data[2]=ReadOneByte(MP_Limit_Max11); 
				Read_Data[3]=ReadOneByte(MP_Limit_Max12); 
				P_Limit_Min=(Read_Data[0]<<8)+Read_Data[1];
				P_Limit_Max=(Read_Data[2]<<8)+Read_Data[3];
 //ѹ���������ű�������
			
				Read_Data[0]=ReadOneByte(MP_Factor_A21); 
				Read_Data[1]=ReadOneByte(MP_Factor_A22); 
				Read_Data[2]=ReadOneByte(MP_Factor_B21); 
				Read_Data[3]=ReadOneByte(MP_Factor_B22); 
				Read_Data[4]=ReadOneByte(MP_Offset21); 
				Read_Data[5]=ReadOneByte(MP_Offset22); 
				P_Factor_A2=(Read_Data[0]<<8)+Read_Data[1];
				P_Factor_B2=(Read_Data[2]<<8)+Read_Data[3];
				P_Offset2=(Read_Data[4]<<8)+Read_Data[5];
				Read_Data[0]=ReadOneByte(Msign_PorN); 
			if( Read_Data[0]==1)
				sign_Positive=1;
			else if(Read_Data[0]==2)
				sign_Positive=-1;

				Read_Data[0]=ReadOneByte(MP_close_loop_P11); 
				Read_Data[1]=ReadOneByte(MP_close_loop_P12); 
				Read_Data[2]=ReadOneByte(MP_close_loop_P13); 
				Read_Data[3]=ReadOneByte(MP_close_loop_P14); 
				Read_Data[4]=ReadOneByte(MP_close_loop_I11); 
				Read_Data[5]=ReadOneByte(MP_close_loop_I12); 
				Read_Data[6]=ReadOneByte(MP_close_loop_I13); 
				Read_Data[7]=ReadOneByte(MP_close_loop_I14); 
				P_close_loop_P=Int_To_Float((Read_Data[3]<<24)+(Read_Data[2]<<16)+(Read_Data[1]<<8)+Read_Data[0]);
				P_close_loop_I=Int_To_Float((Read_Data[7]<<24)+(Read_Data[6]<<16)+(Read_Data[5]<<8)+Read_Data[4]);						
				P_loop_PID.Kp=P_close_loop_P;
				P_loop_PID.Ki=P_close_loop_I;
				P_loop_PID.Kd=P_close_loop_D;
				arm_pid_init_f32(&P_loop_PID, 1);//ѹ��PID��ʼ��

				Read_Data[0]=ReadOneByte(MQ_close_loop_P11); 
				Read_Data[1]=ReadOneByte(MQ_close_loop_P12); 
				Read_Data[2]=ReadOneByte(MQ_close_loop_P13); 
				Read_Data[3]=ReadOneByte(MQ_close_loop_P14); 
				Read_Data[4]=ReadOneByte(MQ_close_loop_I11); 
				Read_Data[5]=ReadOneByte(MQ_close_loop_I12); 
				Read_Data[6]=ReadOneByte(MQ_close_loop_I13); 
				Read_Data[7]=ReadOneByte(MQ_close_loop_I14); 
				Q_close_loop_P=Int_To_Float((Read_Data[3]<<24)+(Read_Data[2]<<16)+(Read_Data[1]<<8)+Read_Data[0]);
				Q_close_loop_I=Int_To_Float((Read_Data[7]<<24)+(Read_Data[6]<<16)+(Read_Data[5]<<8)+Read_Data[4]);
				Q_loop_PID.Kp=Q_close_loop_P;
				Q_loop_PID.Ki=Q_close_loop_I;
				Q_loop_PID.Kd=Q_close_loop_D;
				arm_pid_init_f32(&Q_loop_PID, 1);//����PID��ʼ��
				
				Read_Data[0]=ReadOneByte(MI_close_loop_P11); 
				Read_Data[1]=ReadOneByte(MI_close_loop_P12); 
				Read_Data[2]=ReadOneByte(MI_close_loop_P13); 
				Read_Data[3]=ReadOneByte(MI_close_loop_P14); 
				Read_Data[4]=ReadOneByte(MI_close_loop_I11); 
				Read_Data[5]=ReadOneByte(MI_close_loop_I12); 
				Read_Data[6]=ReadOneByte(MI_close_loop_I13); 
				Read_Data[7]=ReadOneByte(MI_close_loop_I14); 
				I_close_loop_P=Int_To_Float((Read_Data[3]<<24)+(Read_Data[2]<<16)+(Read_Data[1]<<8)+Read_Data[0]);
				I_close_loop_I=Int_To_Float((Read_Data[7]<<24)+(Read_Data[6]<<16)+(Read_Data[5]<<8)+Read_Data[4]);
				I_loop_PID.Kp=I_close_loop_P;
				I_loop_PID.Ki=I_close_loop_I;
				I_loop_PID.Kd=I_close_loop_D;
				arm_pid_init_f32(&I_loop_PID, 1);//����PID��ʼ��

				Read_Data[0]=ReadOneByte(MQ_Factor_A11); 
				Read_Data[1]=ReadOneByte(MQ_Factor_A12); 
				Read_Data[2]=ReadOneByte(MQ_Factor_B11); 
				Read_Data[3]=ReadOneByte(MQ_Factor_B12);
				Read_Data[4]=ReadOneByte(MQ_Offset11); 
				Read_Data[5]=ReadOneByte(MQ_Offset12);
			//)//��оλ��λ������źŵ���������������Ϊ�ٷ���*100
				Q_Factor_A1=(Read_Data[0]<<8)+Read_Data[1];
				Q_Factor_B1=(Read_Data[2]<<8)+Read_Data[3];
				Q_Offset1=(Read_Data[4]<<8)+Read_Data[5];
				Read_Data[0]=ReadOneByte(MP_Factor_A11); 
				Read_Data[1]=ReadOneByte(MP_Factor_A12); 
				Read_Data[2]=ReadOneByte(MP_Factor_B11); 
				Read_Data[3]=ReadOneByte(MP_Factor_B12);
				Read_Data[4]=ReadOneByte(MP_Offset11); 
				Read_Data[5]=ReadOneByte(MP_Offset12);
				
				P_Factor_A1=(Read_Data[0]<<8)+Read_Data[1];
				P_Factor_A1=(Read_Data[2]<<8)+Read_Data[3];
				P_Offset1=(Read_Data[4]<<8)+Read_Data[5];

				Runmode=ReadLenByte(M_runmode,1);
				Read_Data[0]=ReadOneByte(MCurrent_OpenPwm11);
				Read_Data[1]=ReadOneByte(MCurrent_OpenPwm12);
				duty=((Read_Data[0]<<8)+Read_Data[1]);
	
				Read_Data[0]=ReadOneByte(MCurrent_CloseValue_Set11);
				Read_Data[1]=ReadOneByte(MCurrent_CloseValue_Set12);
				I_Target=((Read_Data[0]<<8)+Read_Data[1]);
				
				Read_Data[0]=ReadOneByte(MSpool_CloseValue_Set11);
				Read_Data[1]=ReadOneByte(MSpool_CloseValue_Set12);
				Q_Target=((Read_Data[0]<<8)+Read_Data[1])/1.0;

				Read_Data[0]=ReadOneByte(MP_CloseValue_Set11);
				Read_Data[1]=ReadOneByte(MP_CloseValue_Set12);
				P_Target=((Read_Data[0]<<8)+Read_Data[1])/1.0;


				Read_Data[0]=ReadOneByte(M_Input_type);
				Input_type=Read_Data[0];
				Input_P_type=ReadOneByte(MTarget_type11);
				Input_Q_type=ReadOneByte(MTarget_type12);
//////////////////////////////////////////////////////////����ֵ�趨��ȡ
				 Read_Data[0]=ReadOneByte(M_I_default11);       //��Ȧ�����쳣
				 Read_Data[1]=ReadOneByte(M_I_default12);
				 I_default=((Read_Data[0]<<8)+Read_Data[1]);
				 if(I_default>100)
				 I_default=I_default-65536;

				 Read_Data[0]=ReadOneByte(M_Spool_zero11);
				 Read_Data[1]=ReadOneByte(M_Spool_zero12);
				 Spool_zero_default=((Read_Data[0]<<8)+Read_Data[1]);
				 if(Spool_zero_default>100)
				 Spool_zero_default=Spool_zero_default-65536;
				 
				 Read_Data[0]=ReadOneByte(M_Spool_default11);
				 Read_Data[1]=ReadOneByte(M_Spool_default12);
				 Spool_default=((Read_Data[0]<<8)+Read_Data[1]);
				 if(Spool_default>100)
				 Spool_default=Spool_default-65536;
				 
				 Read_Data[0]=ReadOneByte(M_initial);        //�ָ�����ֵ
				 if(Read_Data[0]==1)
				 {Spool_default=5;I_default=5;Spool_zero_default=5;}
				 Init_error_flag=1;
				 
				 Read_Data[0]=ReadOneByte(AI1type_adr);          //���ģʽ����
				 Read_Data[1]=ReadOneByte(AI2type_adr);  
				 Read_Data[2]=ReadOneByte(AI3type_adr);
				 Read_Data[3]=ReadOneByte(AI4type_adr);				 
				 AI1type=Read_Data[0];
				 AI2type=Read_Data[1];
				 AI3type=Read_Data[2];
				 AI4type=Read_Data[3];
				 
				 if(AI1type==1)
						Input_P_type=1;
					if(AI1type==2)
						Input_P_type=2;
					
					if(AI2type==1)
						Input_P_type=3;
					if(AI2type==2)
						Input_P_type=4;
					if(AI2type==3)
						Input_P_type=5;
					if(AI2type==4)
						Input_P_type=6;
					
					if(AI3type==1)
						Input_Q_type=1;
					if(AI3type==2)
						Input_Q_type=2;
					
					if(AI4type==1)
						Input_Q_type=3;
					if(AI4type==2)
						Input_Q_type=4;
					if(AI4type==3)
						Input_Q_type=5;
					if(AI4type==4)
						Input_Q_type=6;
		}
}





