#include "main.h"
#include "CAN.h"

extern volatile unsigned short m_ADCValue[ADC_SAMPLE_PNUM][ADC_SAMPLE_CNUM] ;

int can_test_1[8]={0};


struct TaskStruct TaskST[]=
{
 //  ��ʱ   ���ٸ�100us����һ��    �������б�־λ    ������ָ��
	{ 0,         10,              0,            adc_task},
	{ 0,         10,              0,            PID_task},
	{ 0,       2000,              0,        warning_task},
	{ 0,       1000,              0,            CAN_task},
	{ 0,      50000,              0,           Feed_task},
//	{ 0,      100,              0,           cantest_task},

};

unsigned char TaskCount=sizeof(TaskST)/sizeof(TaskST[0]);

extern arm_pid_instance_f32  P_loop_PID;  
extern arm_pid_instance_f32  I_loop_PID;
extern arm_pid_instance_f32  Q_loop_PID;

//extern float LIULIANGPID;
extern int Runmode,DAC_ONOFF;//����ģʽ
extern int  Feedback_buf[8];//����״̬����
extern uint8_t AI1type,AI2type,AI3type,AI4type;//ģ�����������ͣ�����ģ�����������Ͷ���
extern u8 Pid_flow_pressure_flag;//˫�ջ���־λ
extern float Flow_setting;       //ѹ���ջ������趨ֵ
extern float duty,Q_duty ,P_duty ;
extern float C_PrepareSeting; 
extern float Out_I,Out_V,Out_Scale,Out_gain,Out_deadzoom,Out_zero,P_fuhao,Out_Q1,Out_P1,ZERO_COrrect1;//�źŵ����������ֵ
extern uint16_t Trunled;
extern int duty_flag;    //�ж�duty������
extern float duty_now;   //ʵ����Ȧ������Ӧ��ռ�ձ�
extern uint16_t T_can1send,T_can2send;
extern uint64_t T_Analog_input,T_Constant_input,T_Other_status,T_Analog_input_1;

extern uint64_t Flag_500ms,Default_ms,Pre_ms,can1_bling;
extern float   I_Target,P_Target,Q_Target;//������ѹ����������������
extern 	int  Input_P_type,Input_Q_type,Input_type,Output_type_P,Output_type_Q; //�����������루ѹ��������
extern  int  P_Factor_A1,  P_Factor_B1,  Q_Factor_A1,  Q_Factor_B1,   P_Offset1,Q_Offset1,
             P_Factor_A2,  P_Factor_B2,  Q_Factor_A2,  Q_Factor_B2,   P_Offset2,Q_Offset2,
             P_Factor_A3,  P_Factor_B3,  Q_Factor_A3,  Q_Factor_B3,   Q_Factor_A4,Q_Factor_B4,
             minzerovalue, maxzerovalue, Offset_zero,  Q_ZERO,P_ZERO, Q_Offset;  //�źŵ���ϵ��
extern int    Q_Limit_Min, Q_Limit_Max,  P_Limit_Max,P_Limit_Min;
extern float  P_close_loop_P,P_close_loop_I,P_close_loop_D,
	            Q_close_loop_P,Q_close_loop_I,Q_close_loop_D,
              I_close_loop_P,I_close_loop_I,I_close_loop_D; ////ѹ��������������������
extern float  I_default,Spool_default,Spool_zero_default;  //����ֵ�趨
extern int     sign_Positive;  //ѹ�������������趨
extern u8     ARR_pwm,PSC_pwm;
extern u8     Flag_PIDchange_Flow,Flag_PIDchange_Pre,Flag_PIDchange_Current,CPU_restart;  //��λ������PID������־λ
extern u8     PWM_FLAG;
extern float AD_init_test;      //AD��ʼ���� �жϵ�һ�β���ֵ�Ƿ���ȷ
extern u8 Init_error_flag;
extern u8 Read_Data[16];
extern u8 tt1,AD_errorflag,Powerstatus;  //AD���ϼ��
extern int CAN1_float_values,CAN1_RT_ERROR;   //can�շ������־
extern u16  ii1,ii2,ii3;
extern float ADC_Value_8[10];   //�ٷ���
extern float A_duty;
extern float temp_T;
extern u8  worning;
extern u8 Power24_stat,Enable_stat,Power_enforce;
extern u32 can_send1[8];
extern int arr_flag,psc_flag;

float liulianggeiding=0.0;
unsigned char dianliubihuan_count=0;
unsigned int pid_count=0;

unsigned char flag_p=0;


//�����ʱ����
void OS_IT_RUN(void)
{
	unsigned char i;
	for(i=0;i<TaskCount;i++)//��������ѭ��
	{	
		if(!TaskST[i].TaskStatus)
		{		
			if(++TaskST[i].TaskTickNow >= TaskST[i].TaskTickMax)//��ʱ�����ж��Ƿ񵽴ﶨʱʱ��
			{	
				TaskST[i].TaskTickNow = 0;		
				TaskST[i].TaskStatus = 1;
			}
		}
	}
}

//ִ�й���������
void PeachOSRun(void)
{
	unsigned char j=0;
	while(1)
	{
		if(Init_error_flag==6)                    //Init_error_flag==6                
		{	
			if(Enable_stat==0|Power_enforce==1)    //�ⲿ����24V��Դʹ�ܣ���⵽�͵�ƽ����������ǿ������
			{	
					if(TaskST[j].TaskStatus)//�ж�һ�������Ƿ񱻹���
					{		
						TaskST[j].FC();				//ִ�и�������
						TaskST[j].TaskStatus=0;		//ȡ������Ĺ���״̬
					}
					if(++j>=TaskCount)//�൱�ڲ���ѭ���������е�����
						j=0;
			 }
		 }	 
	}
}



void adc_task()
{
	Get_Adcvalue(ADC_Value_8);
}

void PID_task()
{
	   A_duty=duty/100.0;
       if(Runmode==1)    //��������
	   { 
		   
	   PWM_Dutyset(A_duty);
 
	   }
	else if(Runmode==2)    //�����ջ�
	   { 
			 
	   if(I_Target>150)
		 I_Target=I_Target-65536;
		 duty = Current_PID(I_Target,ADC_Value_8[0]);//�����ջ�PID����
		 PWM_Dutyset(duty);	

		}						
  else if(Runmode==4)    //�����ջ�
		{    
	  if(Input_type==2)  //�ж��������������Ƿ���
		{
		 if(Input_Q_type==1)  //+- 10V����
			 {
				 ZERO_COrrect1=Zerocorrection(ADC_Value_8[6],Offset_zero);
				 Out_V=Limitfuntion(ZERO_COrrect1, Q_Limit_Min, Q_Limit_Max);    //�޷�����   +-10V
				 Out_Scale=Scalfuntion(Out_V,Q_Factor_A2,Q_Factor_B2,Q_Offset2);	//���ű�������	
				 Out_gain= Gainfuntion(Out_Scale,Q_Factor_A3,Q_Factor_B3,Q_Factor_A4,Q_Factor_B4);   //������������
				 Out_deadzoom=Deadbandfunction(Out_gain,Q_Limit_Min,minzerovalue,maxzerovalue,Q_Limit_Max);	//��������
				 
//				 LIULIANGPID=(ADC_Value_8[1]-40.59)*3.366;
//				 duty = Flow_PID(Out_deadzoom,LIULIANGPID);
				 
//		 				 LIULIANGPID=ADC_Value_8[1];
				 /*
				if(ZERO_COrrect1>=-2&ZERO_COrrect1<=2)
				{ 	
//				if(ZERO_COrrect1-ADC_Value_8[1]<=2&ZERO_COrrect1-ADC_Value_8[1]>=-2)
				 { Q_loop_PID.Kp=0.04;
						 Q_loop_PID.Ki=0.00005;
						 Q_loop_PID.Kd=Q_close_loop_D;
//						 arm_pid_reset_f32(&Q_loop_PID);
						 arm_pid_init_f32(&Q_loop_PID, 0);
				 }
//				 else 
//				 {
//					 Q_loop_PID.Kp=Q_close_loop_P;
//						 Q_loop_PID.Ki=Q_close_loop_I;
//						 Q_loop_PID.Kd=Q_close_loop_D;
//						//						 arm_pid_reset_f32(&Q_loop_PID);
//						 arm_pid_init_f32(&Q_loop_PID, 0);
//				 }
			 }
				else 
				 {
					 Q_loop_PID.Kp=Q_close_loop_P;
						 Q_loop_PID.Ki=Q_close_loop_I;
						 Q_loop_PID.Kd=Q_close_loop_D;
						//						 arm_pid_reset_f32(&Q_loop_PID);
						 arm_pid_init_f32(&Q_loop_PID, 0);
				 }
				 
				 */
				 
				 
//				  	if(((Out_deadzoom-ADC_Value_8[1])<=0.1)&&((Out_deadzoom-ADC_Value_8[1])>=-0.1)&&((Out_deadzoom<=-5)||(Out_deadzoom>=5)))
//							{
//								Q_loop_PID.Kp=Q_close_loop_P*1;
//								Q_loop_PID.Ki=Q_close_loop_I*0.1;
//								Q_loop_PID.Kd=Q_close_loop_D;
//								arm_pid_init_f32(&Q_loop_PID, 0);
//							}
//						else if((Out_deadzoom>-5)&&(Out_deadzoom<5))
//						{
//							  Q_loop_PID.Kp=Q_close_loop_P;
//								Q_loop_PID.Ki=Q_close_loop_I;
//								Q_loop_PID.Kd=Q_close_loop_D;
//								arm_pid_init_f32(&Q_loop_PID, 0);
//						}
//							else
//							{
//								Q_loop_PID.Kp=Q_close_loop_P;
//								Q_loop_PID.Ki=Q_close_loop_I;
//								Q_loop_PID.Kd=Q_close_loop_D;
//								arm_pid_init_f32(&Q_loop_PID, 0);
//							}


					if(((Out_deadzoom-ADC_Value_8[1])<=0.1)&&((Out_deadzoom-ADC_Value_8[1])>=-0.1))
							{
								Q_loop_PID.Kp=Q_close_loop_P*1;
								Q_loop_PID.Ki=Q_close_loop_I*0.1;
								Q_loop_PID.Kd=Q_close_loop_D;
								arm_pid_init_f32(&Q_loop_PID, 0);
							}
						
							else
							{
								Q_loop_PID.Kp=Q_close_loop_P;
								Q_loop_PID.Ki=Q_close_loop_I;
								Q_loop_PID.Kd=Q_close_loop_D;
								arm_pid_init_f32(&Q_loop_PID, 0);
							}

			 duty = Flow_PID(Out_deadzoom,ADC_Value_8[1]);		
//            LIULIANGPID=0;	

			 }
     else if (Input_Q_type==2)  //0 -10v
			 {
				 ZERO_COrrect1=Zerocorrection(ADC_Value_8[6],Offset_zero);
				 Out_V=Limitfuntion(ZERO_COrrect1, Q_Limit_Min, Q_Limit_Max);    //�޷�����   +-10V
				 Out_Scale=Scalfuntion(Out_V,Q_Factor_A2,Q_Factor_B2,Q_Offset2);	//���ű�������	
				 Out_gain= Gainfuntion(Out_Scale,Q_Factor_A3,Q_Factor_B3,Q_Factor_A4,Q_Factor_B4);   //������������
				 Out_deadzoom=Deadbandfunction(Out_gain,Q_Limit_Min,minzerovalue,maxzerovalue,Q_Limit_Max);	//��������

				 duty = Flow_PID(Out_deadzoom,ADC_Value_8[1]);	
		     }
	 else if(Input_Q_type==3)  //+-10mA
			 {
				 ZERO_COrrect1=Zerocorrection(ADC_Value_8[3],Offset_zero);
				 Out_I=Limitfuntion( ZERO_COrrect1, Q_Limit_Min, Q_Limit_Max);    //�޷�����   +-10V
				 Out_Scale=Scalfuntion(Out_I,Q_Factor_A2,Q_Factor_B2,Q_Offset2);	//���ű�������	
				 Out_gain= Gainfuntion(Out_Scale,Q_Factor_A3,Q_Factor_B3,Q_Factor_A4,Q_Factor_B4);   //������������
				 Out_deadzoom=Deadbandfunction(Out_deadzoom,Q_Limit_Min,minzerovalue,maxzerovalue,Q_Limit_Max);	//��������		 
				 duty = Flow_PID(Out_deadzoom,ADC_Value_8[1]);						 
			 }							 
	 else if(Input_Q_type==4)  //0-10mA     
			 {
				 ZERO_COrrect1=Zerocorrection(ADC_Value_8[3],Offset_zero);
				 Out_I=Limitfuntion( ZERO_COrrect1, Q_Limit_Min, Q_Limit_Max);    //�޷�����   +-10V
				 Out_Scale=Scalfuntion(Out_I,Q_Factor_A2,Q_Factor_B2,Q_Offset2);	//���ű�������	
				 Out_gain= Gainfuntion(Out_Scale,Q_Factor_A3,Q_Factor_B3,Q_Factor_A4,Q_Factor_B4);   //������������
				 Out_deadzoom=Deadbandfunction(Out_deadzoom,Q_Limit_Min,minzerovalue,maxzerovalue,Q_Limit_Max);	//��������		 
				 duty = Flow_PID(Out_deadzoom,ADC_Value_8[1]);							 
			 }
	 else if(Input_Q_type==5)  //4-20mA   +-100%
		    {
				 ZERO_COrrect1=Zerocorrection(ADC_Value_8[3],Offset_zero);
				 Out_I=Limitfuntion( ZERO_COrrect1, Q_Limit_Min, Q_Limit_Max);    //�޷�����   +-10V
				 Out_Scale=Scalfuntion(Out_I,Q_Factor_A2,Q_Factor_B2,Q_Offset2);	//���ű�������	
				 Out_gain= Gainfuntion(Out_Scale,Q_Factor_A3,Q_Factor_B3,Q_Factor_A4,Q_Factor_B4);   //������������
				 Out_deadzoom=Deadbandfunction(Out_deadzoom,Q_Limit_Min,minzerovalue,maxzerovalue,Q_Limit_Max);	//��������		 
				 duty = Flow_PID(Out_deadzoom,ADC_Value_8[1]);						  
		    }			 
	 else if(Input_Q_type==6)  //4-20mA   0-100%
		   {
				 ZERO_COrrect1=Zerocorrection(ADC_Value_8[3],Offset_zero);
				 Out_I=Limitfuntion( ZERO_COrrect1, Q_Limit_Min, Q_Limit_Max);    //�޷�����   +-10V
				 Out_Scale=Scalfuntion(Out_I,Q_Factor_A2,Q_Factor_B2,Q_Offset2);	//���ű�������	
				 Out_gain= Gainfuntion(Out_Scale,Q_Factor_A3,Q_Factor_B3,Q_Factor_A4,Q_Factor_B4);   //������������
				 Out_deadzoom=Deadbandfunction(Out_deadzoom,Q_Limit_Min,minzerovalue,maxzerovalue,Q_Limit_Max);	//��������		 
				 duty = Flow_PID(Out_deadzoom,ADC_Value_8[1]);	
		   }	
		}
       else 
		  {					 
				 if(Q_Target>150)
				 Q_Target=Q_Target-65536;
//				 LIULIANGPID=(ADC_Value_8[1]-40.59)*3.366;
//				 LIULIANGPID=ADC_Value_8[1];
				 
				 /*
				 //�ֶ�PI
				 if(Q_Target==0)
				 {
					 Q_close_loop_P=0.05;
				   Q_close_loop_I=0.00005;
				 }
				 else if(Q_Target>0&Q_Target<=40)
				 {
					 Q_close_loop_P=0.085;
				   Q_close_loop_I=0;
				 }
				 else if(Q_Target>40&Q_Target<=60)
				 {
					 Q_close_loop_P=0.08;
				   Q_close_loop_I=0;
				 }
				 else if(Q_Target>60&Q_Target<=80)
				 {
					 Q_close_loop_P=0.065;
				   Q_close_loop_I=0;
				 }
				 else if(Q_Target>80&Q_Target<=100)
				 {
					 Q_close_loop_P=0.028;
				   Q_close_loop_I=0.00001;
				 }
				 					 Q_loop_PID.Kp=Q_close_loop_P;
					 Q_loop_PID.Ki=Q_close_loop_I;
					 Q_loop_PID.Kd=Q_close_loop_D;

					 */
					 
					 /*
					 if(Q_Target-ADC_Value_8[1]>=60|Q_Target-ADC_Value_8[1]<=-60)
					 {
						 Q_loop_PID.Kp=Q_close_loop_P*2;
						 Q_loop_PID.Ki=Q_close_loop_I*0.2;
						 Q_loop_PID.Kd=Q_close_loop_D;
//						 arm_pid_reset_f32(&Q_loop_PID);
						 arm_pid_init_f32(&Q_loop_PID, 0);
					 }
					 else if((Q_Target-ADC_Value_8[1]>=40&Q_Target-ADC_Value_8[1]<60)|(Q_Target-ADC_Value_8[1]>-60&Q_Target-ADC_Value_8[1]<=-40))
					 {
						 Q_loop_PID.Kp=Q_close_loop_P*1.5;
						 Q_loop_PID.Ki=Q_close_loop_I*0.5;
						 Q_loop_PID.Kd=Q_close_loop_D;
//						 arm_pid_reset_f32(&Q_loop_PID);
						 arm_pid_init_f32(&Q_loop_PID, 0);
					 }
					 else if((Q_Target-ADC_Value_8[1]>=20&Q_Target-ADC_Value_8[1]<40)|(Q_Target-ADC_Value_8[1]>-40&Q_Target-ADC_Value_8[1]<=-20))
					 {
						 Q_loop_PID.Kp=Q_close_loop_P;
						 Q_loop_PID.Ki=Q_close_loop_I*2;
						 Q_loop_PID.Kd=Q_close_loop_D;
//						 arm_pid_reset_f32(&Q_loop_PID);
						 arm_pid_init_f32(&Q_loop_PID, 0);
					 }
					 else if((Q_Target-ADC_Value_8[1]>=0&Q_Target-ADC_Value_8[1]<20)|(Q_Target-ADC_Value_8[1]>-20&Q_Target-ADC_Value_8[1]<=0))
					 {
						 Q_loop_PID.Kp=Q_close_loop_P;
						 Q_loop_PID.Ki=Q_close_loop_I;
						 Q_loop_PID.Kd=Q_close_loop_D;
						//						 arm_pid_reset_f32(&Q_loop_PID);
						 arm_pid_init_f32(&Q_loop_PID, 0);
					 }
				 */
				 
				 
				 
//				 if(Q_Target-ADC_Value_8[1]<=2&Q_Target-ADC_Value_8[1]>-2)
//				 { Q_loop_PID.Kp=0.04;
//						 Q_loop_PID.Ki=0.00005;
//						 Q_loop_PID.Kd=Q_close_loop_D;
////						 arm_pid_reset_f32(&Q_loop_PID);
//						 arm_pid_init_f32(&Q_loop_PID, 0);
//				 }
//				 else 
//				 {
//					 Q_loop_PID.Kp=Q_close_loop_P;
//						 Q_loop_PID.Ki=Q_close_loop_I;
//						 Q_loop_PID.Kd=Q_close_loop_D;
//						//						 arm_pid_reset_f32(&Q_loop_PID);
//						 arm_pid_init_f32(&Q_loop_PID, 0);
//				 }
					 
					 	if(((Q_Target-ADC_Value_8[1])<=0.2)&&((Q_Target-ADC_Value_8[1])>=-0.2))
							{
								Q_loop_PID.Kp=Q_close_loop_P*1.5;
								Q_loop_PID.Ki=Q_close_loop_I*0.1;
								Q_loop_PID.Kd=Q_close_loop_D;
								arm_pid_init_f32(&Q_loop_PID, 0);
							}
							else
							{
								Q_loop_PID.Kp=Q_close_loop_P;
								Q_loop_PID.Ki=Q_close_loop_I;
								Q_loop_PID.Kd=Q_close_loop_D;
								arm_pid_init_f32(&Q_loop_PID, 0);
							}
				 				 duty = Flow_PID(Q_Target,ADC_Value_8[1]);				 
				
//				 if(dianliubihuan_count>=3)
//				 {
//					liulianggeiding = Flow_PID(Q_Target,ADC_Value_8[1]);	
//					dianliubihuan_count=0;
//				 }
//				 if(liulianggeiding>1)
//					 liulianggeiding=1;
//				 if(liulianggeiding<-1)
//					 liulianggeiding=-1;
//				 
//				 duty = Current_PID(liulianggeiding*100,ADC_Value_8[0]);//�����ջ�PID����
//				 dianliubihuan_count++;
				 

				 
				 
				 
		  }
		         PWM_Dutyset(duty);	
	}
	 else if(Runmode==6)  //ѹ���ջ�
		{
			if(Input_type==2)  //�ж��������������Ƿ���
			{			
				
				if(Input_P_type==1)  //ѹ������ ��ѹ��  +-10V
				{
					 Out_V=Limitfuntion(ADC_Value_8[5], P_Limit_Min, P_Limit_Max);    //�޷�����   +-10V
					 Out_Scale=Scalfuntion(Out_V,P_Factor_A2,P_Factor_B2,P_Offset2);	//���ű�������	


//if(Out_Scale>=8&&Out_Scale<=9&&flag_p==0)
//					{
//						P_loop_PID.Kp=P_close_loop_P*23/24;
//						P_loop_PID.Ki=P_close_loop_I*11/16;
//						P_loop_PID.Kd=P_close_loop_D;
//						arm_pid_init_f32(&P_loop_PID, 0);
//						flag_p=1;
//					}					
//					else if(Out_Scale>9&&flag_p==1)
//					{
//						P_loop_PID.Kp=P_close_loop_P;
//						P_loop_PID.Ki=P_close_loop_I;
//						P_loop_PID.Kd=P_close_loop_D;
//						arm_pid_init_f32(&P_loop_PID, 0);
//						flag_p=0;
//					}




					
				}
				
				else if(Input_P_type==2)  //0-10v
				{
					 Out_V=Limitfuntion(ADC_Value_8[5], P_Limit_Min, P_Limit_Max);    //�޷�����   +-10V
					 Out_Scale=Scalfuntion(Out_V,P_Factor_A2,P_Factor_B2,P_Offset2);	//���ű�������	
				}	
				
				else if(Input_P_type==3)//+-10ma
				{
					 Out_V=Limitfuntion(ADC_Value_8[4], P_Limit_Min, P_Limit_Max);    //�޷�����   +-10V
					 Out_Scale=Scalfuntion(Out_V,P_Factor_A2,P_Factor_B2,P_Offset2);	//���ű�������	
				}	
				
				else if(Input_P_type==4)//0-10ma
				{
					 Out_V=Limitfuntion(ADC_Value_8[4], P_Limit_Min, P_Limit_Max);    //�޷�����   +-10V
					 Out_Scale=Scalfuntion(Out_V,P_Factor_A2,P_Factor_B2,P_Offset2);	//���ű�������	
				}	
				
				else if(Input_P_type==5)//4-20ma
				{
					 Out_V=Limitfuntion(ADC_Value_8[4], P_Limit_Min, P_Limit_Max);    //�޷�����   +-10V
					 Out_Scale=Scalfuntion(Out_V,P_Factor_A2,P_Factor_B2,P_Offset2);	//���ű�������	
				}	
				
			 else if(Input_P_type==6)//4-20ma
				{
					 Out_V=Limitfuntion(ADC_Value_8[4], P_Limit_Min, P_Limit_Max);    //�޷�����   +-10V
					 Out_Scale=Scalfuntion(Out_V,P_Factor_A2,P_Factor_B2,P_Offset2);	//���ű�������	
				}							
			}								
			else   //û���ⲿ�ź��������
				{
					 sign_Positive=1;
					 Out_Scale=P_Target; 
				}
				
	
//					duty = Flow_PID(Flow_setting*100,ADC_Value_8[1]);    //˫�ջ�
//					Pid_flow_pressure_flag++;			
//			if(Pid_flow_pressure_flag>=Flow_PID_Count)
//				{ 
//					/////////////////////////////////////�ֶ�PI
//					if(((Out_Scale*sign_Positive-ADC_Value_8[2])<=0.1)&&((Out_Scale*sign_Positive-ADC_Value_8[2])>=-0.1))
//					{
//						P_loop_PID.Kp=P_close_loop_P*1;
//						P_loop_PID.Ki=P_close_loop_I*0.1;
//						P_loop_PID.Kd=P_close_loop_D;
//						arm_pid_init_f32(&P_loop_PID, 0);
//					}					
//					else
//					{
//						P_loop_PID.Kp=P_close_loop_P;
//						P_loop_PID.Ki=P_close_loop_I;
//						P_loop_PID.Kd=P_close_loop_D;
//						arm_pid_init_f32(&P_loop_PID, 0);
//					}
//					//////////////////////////////////////////////////////
//					
//					Flow_setting=Pressure_PID(Out_Scale*sign_Positive,ADC_Value_8[2]);
//					Pid_flow_pressure_flag=0;					
//					if(Flow_setting>0.1)	Flow_setting=0.1;
//					if(Flow_setting<-0.1)Flow_setting=-0.1;   
//				}

				
				//����
				/////////////////////////////////////�ֶ�PI
//					if(((Out_Scale*sign_Positive-ADC_Value_8[2])<=0.1)&&((Out_Scale*sign_Positive-ADC_Value_8[2])>=-0.1))
//					{
//						P_loop_PID.Kp=P_close_loop_P*1;
//						P_loop_PID.Ki=P_close_loop_I*0.1;
//						P_loop_PID.Kd=P_close_loop_D;
//						arm_pid_init_f32(&P_loop_PID, 0);
//					}					
//					else
//					{
//						P_loop_PID.Kp=P_close_loop_P;
//						P_loop_PID.Ki=P_close_loop_I;
//						P_loop_PID.Kd=P_close_loop_D;
//						arm_pid_init_f32(&P_loop_PID, 0);
//					}
				
//				if(((ADC_Value_8[2])>=15))
//				{
//					P_loop_PID.Kp=P_close_loop_P*2;
//					P_loop_PID.Ki=P_close_loop_I*1.5;
//					P_loop_PID.Kd=P_close_loop_D;
//					arm_pid_init_f32(&P_loop_PID, 0);
//				}					
//				else
//				{
//					P_loop_PID.Kp=P_close_loop_P;
//					P_loop_PID.Ki=P_close_loop_I;
//					P_loop_PID.Kd=P_close_loop_D;
//					arm_pid_init_f32(&P_loop_PID, 0);
//				}
			
				
				duty=Pressure_PID(Out_Scale*sign_Positive,ADC_Value_8[2]);
					Pid_flow_pressure_flag=0;					
					if(duty>0.1) duty=0.1;
					if(duty<-0.1) duty=-0.1;   
				
				
					PWM_Dutyset(duty);
			}
		
			
//	if(Trunled>(T_DAC*TimerN))   //320ms  DAC��ʱ���
//					{
//						
//					Out_Q1=OUT_positionprocess(ADCvalue_Percent[6],Q_Factor_A1,Q_Factor_B1,Q_Offset1);//��оλ��λ������źŵ���������������Ϊ�ٷ���*100
//					Out_P1=OUT_Pressurerocess(ADCvalue_Percent[3], P_Factor_A1 , P_Factor_B1,P_Offset1);//��оλ��λ������źŵ���������������Ϊ�ٷ���*100
//		              if(DAC_ONOFF==2)
//									{
//									Dac2_Set_Vol(Out_P1);
//                  Dac1_Set_Vol(Out_Q1);
//									}
//							Trunled=0;
//					}					 
					 //			//CAN1��������-��ʱ����

					


   PID_change();
			
//			if(pid_count>=5000)
//				pid_count=0;
//			pid_count++;

}

void warning_task()
{
	if((ADC_Value_8[2]<=0)||(ADC_Value_8[2]>=100))  //ѹ������������  1MPa ���� 0.267V  0-30mpa
		 worning++;
	if((ADC_Value_8[2]>=83.44)&(ADC_Value_8[2]<100)) //ѹ�����߱���
	if(ADC_Value_8[7]<0||ADC_Value_8[7]>100)  //�¶ȴ���������
		 worning++;
	if(((ADC_Value_8[7]<=13.8)&(ADC_Value_8[7]>=0))||((ADC_Value_8[7]>=82.8)&(ADC_Value_8[7]<=100))) //�¶ȹ��߹��ͱ���
		 worning++;
	if(fabs(ADC_Value_8[0])<2)					//��Ȧ�����Ͽ��������ߵ������ͱ���
		 worning++; 
	if(worning>0)
		{  
				Green1(0);Blue1(0);Red1(1);
					 ERROR_CHECK(1);
		}
	else
		{  
				Green1(0);Blue1(0);Green1(1);
					 ERROR_CHECK(0);
		}		
  if(CPU_restart==1)
		{
					RestartCPU();
					CPU_restart=0;
		}	
	if(CAN1_RT_ERROR>0) 
	  {
					Blue2(0);Green2(0);Red2(1);							    
					ERROR_CHECK(1);
					CAN1_RT_ERROR=0;
	  }
		else 
	 {  
		Blue2(0);Red2(0);Green2(0);							    
		ERROR_CHECK(0);
	 }							
}

void CAN_task()
{
	Feedback_buf[0]=1;
	Feedback_buf[1]=Runmode;
	Feedback_buf[2]=2;//ͨ��0  ����Ȧ����		
	CAN1_float_values=Float_To_Int(ADC_Value_8[0]*100);
	Feedback_buf[3]=(CAN1_float_values&0XFF);//L8
	Feedback_buf[4]=((CAN1_float_values&0XFF00)>>8);
	Feedback_buf[5]=((CAN1_float_values&0XFF0000)>>16);
	Feedback_buf[6]=((CAN1_float_values>>24)&0XFF);
	CAN1_Send_Msg(CANID_stats,Feedback_buf,8);    
	

	Feedback_buf[2]=6;//ͨ��1  ��оλ��	
	CAN1_float_values=Float_To_Int(ADC_Value_8[1]*100);	
	Feedback_buf[3]=(CAN1_float_values&0XFF);
	Feedback_buf[4]=((CAN1_float_values&0XFF00)>>8);
	Feedback_buf[5]=((CAN1_float_values&0XFF0000)>>16);
	Feedback_buf[6]=((CAN1_float_values>>24)&0XFF);
	CAN1_Send_Msg(CANID_stats,Feedback_buf,8);    
	

	Feedback_buf[2]=3;//ͨ��2  ѹ��
	CAN1_float_values=Float_To_Int(ADC_Value_8[2]*100);	
	Feedback_buf[3]=(CAN1_float_values&0XFF);
	Feedback_buf[4]=((CAN1_float_values&0XFF00)>>8);
	Feedback_buf[5]=((CAN1_float_values&0XFF0000)>>16);
	Feedback_buf[6]=((CAN1_float_values>>24)&0XFF);
	CAN1_Send_Msg(CANID_stats,Feedback_buf,8); 
	
	Feedback_buf[2]=10;//�ⲿģ�������� AD0
	CAN1_float_values=Float_To_Int(ADC_Value_8[5]*100);	
	Feedback_buf[3]=(CAN1_float_values&0XFF);
	Feedback_buf[4]=((CAN1_float_values&0XFF00)>>8);
	Feedback_buf[5]=((CAN1_float_values&0XFF0000)>>16);
	Feedback_buf[6]=((CAN1_float_values>>24)&0XFF);
//						  CAN1_float_values=(Feedback_buf[6]<<24)+(Feedback_buf[5]<<16)+(Feedback_buf[4]<<8)+Feedback_buf[3];
	CAN1_Send_Msg(CANID_stats,Feedback_buf,8); 
	
	Feedback_buf[2]=11;//�ⲿģ�������� AD1
	CAN1_float_values=Float_To_Int(ADC_Value_8[3]*100);	
	Feedback_buf[3]=(CAN1_float_values&0XFF);
	Feedback_buf[4]=((CAN1_float_values&0XFF00)>>8);
	Feedback_buf[5]=((CAN1_float_values&0XFF0000)>>16);
	Feedback_buf[6]=((CAN1_float_values>>24)&0XFF);
	CAN1_Send_Msg(CANID_stats,Feedback_buf,8); 
	
	Feedback_buf[2]=12;//�ⲿģ�������� AD5
	CAN1_float_values=Float_To_Int(ADC_Value_8[6]*100);	
	Feedback_buf[3]=(CAN1_float_values&0XFF);
	Feedback_buf[4]=((CAN1_float_values&0XFF00)>>8);
	Feedback_buf[5]=((CAN1_float_values&0XFF0000)>>16);
	Feedback_buf[6]=((CAN1_float_values>>24)&0XFF);
	CAN1_Send_Msg(CANID_stats,Feedback_buf,8); 
	
	Feedback_buf[2]=13;//�ⲿģ�������� AD7
	CAN1_float_values=Float_To_Int(ADC_Value_8[4]*100);	
	Feedback_buf[3]=(CAN1_float_values&0XFF);
	Feedback_buf[4]=((CAN1_float_values&0XFF00)>>8);
	Feedback_buf[5]=((CAN1_float_values&0XFF0000)>>16);
	Feedback_buf[6]=((CAN1_float_values>>24)&0XFF);
	CAN1_Send_Msg(CANID_stats,Feedback_buf,8); 
	


//	Feedback_buf[0]=21;             //��������ֵ����
//	CAN1_float_values=Float_To_Int(I_Target*100);	
//	Feedback_buf[4]=(CAN1_float_values&0XFF);
//	Feedback_buf[5]=((CAN1_float_values&0XFF00)>>8);
//	Feedback_buf[6]=((CAN1_float_values&0XFF0000)>>16);
//	Feedback_buf[7]=((CAN1_float_values>>24)&0XFF);
//	CAN1_Send_Msg(CANID_stats,Feedback_buf,8); 
//	
//	Feedback_buf[0]=22;             //��ʾ��������ֵ����
//	CAN1_float_values=Float_To_Int(Q_Target*100);	
//	Feedback_buf[4]=(CAN1_float_values&0XFF);
//	Feedback_buf[5]=((CAN1_float_values&0XFF00)>>8);
//	Feedback_buf[6]=((CAN1_float_values&0XFF0000)>>16);
//	Feedback_buf[7]=((CAN1_float_values>>24)&0XFF);
//	CAN1_Send_Msg(CANID_stats,Feedback_buf,8); 
//	
//	
//	
//	Feedback_buf[0]=30;             //30 ��ʾѹ������ֵ����
//	CAN1_float_values=Float_To_Int(P_Target*100);	
//	Feedback_buf[4]=(CAN1_float_values&0XFF);
//	Feedback_buf[5]=((CAN1_float_values&0XFF00)>>8);
//	Feedback_buf[6]=((CAN1_float_values&0XFF0000)>>16);
//	Feedback_buf[7]=((CAN1_float_values>>24)&0XFF);
//	CAN1_Send_Msg(CANID_stats,Feedback_buf,8); 
		
		
	Feedback_buf[0]=31;             //31  �¶�ֵ����
	CAN1_float_values=Float_To_Int(ADC_Value_8[7]*100);	
	Feedback_buf[4]=(CAN1_float_values&0XFF);
	Feedback_buf[5]=((CAN1_float_values&0XFF00)>>8);
	Feedback_buf[6]=((CAN1_float_values&0XFF0000)>>16);
	Feedback_buf[7]=((CAN1_float_values>>24)&0XFF);
	CAN1_Send_Msg(CANID_stats,Feedback_buf,8); 
	
//	Feedback_buf[0]=32;             //32  ռ�ձ�ֵ����
//	CAN1_float_values=Float_To_Int(duty);	
//	Feedback_buf[4]=(CAN1_float_values&0XFF);
//	Feedback_buf[5]=((CAN1_float_values&0XFF00)>>8);
//	Feedback_buf[6]=((CAN1_float_values&0XFF0000)>>16);
//	Feedback_buf[7]=((CAN1_float_values>>24)&0XFF);
//	CAN1_Send_Msg(CANID_stats,Feedback_buf,8); 
//	T_can1send=0;
}

void Feed_task()
{
	IWDG_Feed();
}
	
void cantest_task()
{
	
	    can_test_1[0]=(unsigned char)(ADC_Proc_Value(6)>>8);
	    can_test_1[1]=(unsigned char)((ADC_Proc_Value(6)&0x0ff)>>4);
		can_test_1[2]=(unsigned char)(ADC_Proc_Value(6)&0x00f);
//		can_test_1[2]=(unsigned char)(m_ADCValue[1][6]>>8);
//	    can_test_1[3]=(unsigned char)(m_ADCValue[1][6]&0x0f);
//		can_test_1[4]=(unsigned char)(m_ADCValue[2][6]>>8);
//	    can_test_1[5]=(unsigned char)(m_ADCValue[2][6]&0x0f);
//		can_test_1[6]=(unsigned char)(m_ADCValue[3][6]>>8);
//	    can_test_1[7]=(unsigned char)(m_ADCValue[3][6]&0x0f);
//	
	CAN1_Send_Msg(CANID_stats,can_test_1,8);
}